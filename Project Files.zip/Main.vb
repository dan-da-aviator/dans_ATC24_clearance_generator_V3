﻿Public Class Main
    Dim airport As String
    Dim standardDepartureRunway As String
    Dim standardInitialClimb As Integer
    Dim initialClimb As String

    Dim airportValidated As Boolean

    Dim callsign As String
    Dim aircraftType As String
    Dim destination As String

    Dim departureMethod As Char
    Dim squawk As String

    Dim customDeparture As String
    Dim customDepartureRunway As String
    Dim customDestination As String
    Dim customClimb As String

    Dim SID(19) As String
    Dim VECTOR(19) As String
    Dim SIDC(19) As String
    Dim VECTORC(19) As String

    Dim AIRPORTINFO(2) As Boolean
    Dim CLEARANCEGEN(4) As Boolean
    Dim CUSTOMENTRIES(3) As Boolean

    Dim departure As String
    Dim departureRunway As String
    Dim PDCS As String

    Dim listBoxItems As Boolean
    Dim abrevDep As String

    Dim PDC(24) As String
    Dim PDCCall As Integer

    Dim centreFreq As String

    Dim custError As String
    Dim climbError As Boolean

    Dim climbCopy As Boolean

    Dim CLEARCOUNT As Integer

    Dim sqk As Boolean


    'ARRAY INDICES RELATIVE TO AIRPORT CODES
    'D0 = IRFD - ROCKFORD INT
    'D1 = IGAR - AIRBASE GARRY
    'D2 = IBLT - BOLTIC AIRFIELD
    'D3 = IMLR - MELLOR INT

    'D4 = ILAR - LARNACA INT
    'D5 = IPAP - PAPHOS INT
    'D6 = IIAB - MCONNEL AFB
    'D7 = IHEN - HENSTRIDGE
    'D8 = IBAR - BARRA

    'D9 = IZOL - IZOLIRANI INT
    'D10 = IJAF - AL NAJAF
    'D11 = ISCM - SCAMPTON

    'D12 = ITKO - TOKYO
    'D13 = IDCS - SABA

    'D14 = IPPH - PERTH
    'D15 = ILKL - LUKLA

    'D16 = IBTH - ST BARTS

    'D17 = ISKP - SKOPELOS

    'D18 = IGRV - GRINDAVIK

    'D19 = ISAU - SAUTHEMTONA
    Private Sub TB1_Leave(sender As Object, e As EventArgs) Handles TB1.Leave
        If TB1.Text = "IRFD" Or TB1.Text = "IMLR" Or TB1.Text = "ILAR" Or TB1.Text = "IPAP" Or TB1.Text = "IIAB" Or TB1.Text = "ITKO" Or TB1.Text = "IPPH" Or TB1.Text = "IGRV" Or TB1.Text = "ISAU" Then
            airport = TB1.Text
            AIRPORTINFO(0) = True
        Else
            AIRPORTINFO(0) = False
        End If
    End Sub
    Private Sub TB2_Leave(sender As Object, e As EventArgs) Handles TB2.Leave
        If TB2.Text = "" Then
            AIRPORTINFO(1) = False
        Else
            AIRPORTINFO(1) = True
            standardDepartureRunway = TB2.Text
        End If
    End Sub
    Private Sub TB3_Leave(sender As Object, e As EventArgs) Handles TB3.Leave
        If IsNumeric(TB3.Text) Then
            If TB3.Text >= 1000 And TB3.Text <= 5000 Then
                AIRPORTINFO(2) = True
                standardInitialClimb = TB3.Text
            Else
                AIRPORTINFO(2) = False
            End If
        Else
            AIRPORTINFO(2) = False
        End If
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If AIRPORTINFO(0) = True And AIRPORTINFO(1) = True And AIRPORTINFO(2) = True Then
            If airport = "IRFD" And (standardDepartureRunway = "07L" Or standardDepartureRunway = "07R" Or standardDepartureRunway = "07C" Or standardDepartureRunway = "25L" Or standardDepartureRunway = "25C" Or standardDepartureRunway = "25R") Then
                airportValidated = True
                If standardDepartureRunway = "25L" Or standardDepartureRunway = "25C" Or standardDepartureRunway = "25R" Then
                    SIDC(0) = "C"
                    SIDC(1) = "N/A"
                    SIDC(2) = "N/A"
                    SIDC(3) = "RFD6 DEP - WESTERN CLIMB. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "OSHNN1 DEP - GRASS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(5) = "OSHNN1 DEP - GRASS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(6) = "OSHNN1 DEP - GRASS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(7) = "OSHNN1 DEP - GRASS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(8) = "OSHNN1 DEP - GRASS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(9) = "OSHNN1 DEP - CYRIL TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(10) = "OSHNN1 DEP - CYRIL TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(11) = "OSHNN1 DEP - CYRIL TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(12) = "LOGAN4 DEP - RENDR TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(13) = "LOGAN4 DEP - RENDR TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(14) = "LOGAN4 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(15) = "LOGAN4 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(16) = "LOGAN4 DEP - DINER TRANS - TERMINATING AT MDWAY. DEP RWY " & standardDepartureRunway & "."
                    SIDC(17) = "OSHNN1 DEP - GRASS TRANS - TERMINATING AT JAMSI. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "DARKK3 DEP - SPACE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(19) = "DARKK3 DEP - SEEKS TRANS. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "C"
                    SID(1) = "N/A"
                    SID(2) = "N/A"
                    SID(3) = "RFD6.WESTERN CLIMB"
                    SID(4) = "OSHNN1.GRASS"
                    SID(5) = "OSHNN1.GRASS"
                    SID(6) = "OSHNN1.GRASS"
                    SID(7) = "OSHNN1.GRASS"
                    SID(8) = "OSHNN1.GRASS"
                    SID(9) = "OSHNN1.CYRIL"
                    SID(10) = "OSHNN1.CYRIL"
                    SID(11) = "OSHNN1.CYRIL"
                    SID(12) = "LOGAN4.RENDR"
                    SID(13) = "LOGAN4.RENDR"
                    SID(14) = "LOGAN4.DINER"
                    SID(15) = "LOGAN4.DINER"
                    SID(16) = "LOGAN4.DINER - TERM MDWAY"
                    SID(17) = "OSHNN1.GRASS - TERM JAMSI"
                    SID(18) = "DARKK3.SPACE"
                    SID(19) = "DARKK3.SEEKS"

                    VECTOR(0) = "C"
                    VECTOR(1) = "FLY RUNWAY HDG"
                    VECTOR(2) = "FLY VISUAL DIRECT"
                    VECTOR(3) = "FLY RUNWAY HDG"
                    VECTOR(4) = "TURN LEFT HDG 150"
                    VECTOR(5) = "TURN LEFT HDG 150"
                    VECTOR(6) = "TURN LEFT HDG 150"
                    VECTOR(7) = "TURN LEFT HDG 150"
                    VECTOR(8) = "TURN LEFT HDG 150"
                    VECTOR(9) = "TURN LEFT HDG 150"
                    VECTOR(10) = "TURN LEFT HDG 150"
                    VECTOR(11) = "TURN LEFT HDG 150"
                    VECTOR(12) = "TURN RIGHT HDG 290"
                    VECTOR(13) = "TURN RIGHT HDG 290"
                    VECTOR(14) = "TURN RIGHT HDG 290"
                    VECTOR(15) = "TURN RIGHT HDG 290"
                    VECTOR(16) = "TURN RIGHT HDG 020"
                    VECTOR(17) = "TURN RIGHT HDG 020"
                    VECTOR(18) = "TURN RIGHT HDG 290"
                    VECTOR(19) = "TURN RIGHT HDG 290"

                    VECTORC(0) = "C"
                    VECTORC(1) = "RWY HDG"
                    VECTORC(2) = "VIS DCT"
                    VECTORC(3) = "RWY HDG"
                    VECTORC(4) = "LH 150"
                    VECTORC(5) = "LH 150"
                    VECTORC(6) = "LH 150"
                    VECTORC(7) = "LH 150"
                    VECTORC(8) = "LH 150"
                    VECTORC(9) = "LH 150"
                    VECTORC(10) = "LH 150"
                    VECTORC(11) = "LH 150"
                    VECTORC(12) = "RH 290"
                    VECTORC(13) = "RH 290"
                    VECTORC(14) = "RH 290"
                    VECTORC(15) = "RH 290"
                    VECTORC(16) = "RH 020"
                    VECTORC(17) = "RH 020"
                    VECTORC(18) = "RH 290"
                    VECTORC(19) = "RH 290"
                ElseIf standardDepartureRunway = "07R" Or standardDepartureRunway = "07C" Or standardDepartureRunway = "07L" Then
                    SIDC(0) = "C"
                    SIDC(1) = "N/A"
                    SIDC(2) = "N/A"
                    SIDC(3) = "RFD6 DEP - NO TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 350."
                    SIDC(4) = "RFD6 DEP - LCK TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT HDG 150."
                    SIDC(5) = "RFD6 DEP - LCK TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT HDG 150."
                    SIDC(6) = "RFD6 DEP - LCK TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT HDG 150."
                    SIDC(7) = "RFD6 DEP - LCK TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT HDG 150."
                    SIDC(8) = "RFD6 DEP - LCK TRANS - AFT DEP RWY " & standardDepartureRunway & " RIGHT HDG 150."
                    SIDC(9) = "WNNDY3 DEP - SILVA TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(10) = "WNNDY3 DEP - SILVA TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(12) = "KENED2 DEP - RENDR TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 310."
                    SIDC(13) = "KENED2 DEP - RENDR TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 310."
                    SIDC(14) = "KENED2 DEP - DINER TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 310."
                    SIDC(15) = "KENED2 DEP - DINER TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 310."
                    SIDC(16) = "KENED2 DEP - DINER TRANS - TERMINATING AT INDEX - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 310."
                    SIDC(17) = "WNNDY3 DEP - NO TRANS - TERMINATING AT WNNDY. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "DARKK3 DEP SPACE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(19) = "DARKK3 DEP SEEKS TRANS. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "C"
                    SID(1) = "N/A"
                    SID(2) = "N/A"
                    SID(3) = "RFD6.NO TRANS - LH 350"
                    SID(4) = "RFD6.LCK - RH 150"
                    SID(5) = "RFD6.LCK - RH 150"
                    SID(6) = "RFD6.LCK - RH 150"
                    SID(7) = "RFD6.LCK - RH 150"
                    SID(8) = "RFD6.LCK - RH 150"
                    SID(9) = "WNNDY3.SILVA"
                    SID(10) = "WNNDY3.SILVA"
                    SID(11) = "WNNDY3.SILVA"
                    SID(12) = "KENED2.RENDR - LH 310"
                    SID(13) = "KENED2.RENDR - LH 310"
                    SID(14) = "KENED2.DINER - LH 310"
                    SID(15) = "KENED2.DINER - LH 310"
                    SID(16) = "KENED2.DINER - LH 310 - TERM INDEX"
                    SID(17) = "WNNDY3.NO TRANS - TERM WNNDY"
                    SID(18) = "DARKK3.SPACE"
                    SID(19) = "DARKK3.SEEKS"

                    VECTOR(0) = "C"
                    VECTOR(1) = "TURN RIGHT HDG 210"
                    VECTOR(2) = "TURN LEFT HDG 350"
                    VECTOR(3) = "TURN LEFT HDG 350"
                    VECTOR(4) = "TURN RIGHT HDG 090"
                    VECTOR(5) = "TURN RIGHT HDG 090"
                    VECTOR(6) = "TURN RIGHT HDG 090"
                    VECTOR(7) = "TURN RIGHT HDG 090"
                    VECTOR(8) = "TURN RIGHT HDG 090"
                    VECTOR(9) = "FLY RUNWAY HDG"
                    VECTOR(10) = "FLY RUNWAY HDG"
                    VECTOR(11) = "FLY RUNWAY HDG"
                    VECTOR(12) = "TURN LEFT HDG 360"
                    VECTOR(13) = "TURN LEFT HDG 360"
                    VECTOR(14) = "TURN LEFT HDG 360"
                    VECTOR(15) = "TURN LEFT HDG 360"
                    VECTOR(16) = "TURN LEFT HDG 360"
                    VECTOR(17) = "FLY RUNWAY HDG"
                    VECTOR(18) = "TURN LEFT HDG 340"
                    VECTOR(19) = "TURN RIGHT HDG 160"

                    VECTORC(0) = "C"
                    VECTORC(1) = "RH 210"
                    VECTORC(2) = "LH 350"
                    VECTORC(3) = "LH 350"
                    VECTORC(4) = "RH 090"
                    VECTORC(5) = "RH 090"
                    VECTORC(6) = "RH 090"
                    VECTORC(7) = "RH 090"
                    VECTORC(8) = "RH 090"
                    VECTORC(9) = "RWY HDG"
                    VECTORC(10) = "RWY HDG"
                    VECTORC(11) = "RWY HDG"
                    VECTORC(12) = "LH 360"
                    VECTORC(13) = "LH 360"
                    VECTORC(14) = "LH 360"
                    VECTORC(15) = "LH 360"
                    VECTORC(16) = "LH 360"
                    VECTORC(17) = "RWY HDG"
                    VECTORC(18) = "LH 340"
                    VECTORC(19) = "RH 160"
                End If
                centreFreq = "124.850MHz."
            ElseIf airport = "IMLR" And (standardDepartureRunway = "25" Or standardDepartureRunway = "07") Then
                airportValidated = True
                If standardDepartureRunway = "25" Then
                    SIDC(0) = "HAWFA1 DEP - NO TRANS - TERMINATING AT HAWFA"
                    SIDC(1) = "MLR1 DEP - GRV TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 180."
                    SIDC(2) = "N/A"
                    SIDC(3) = "C"
                    SIDC(4) = "MLR1 DEP - GRV TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 180."
                    SIDC(5) = "MLR1 DEP - GRV TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 180."
                    SIDC(6) = "MLR1 DEP - GRV TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 180."
                    SIDC(7) = "MLR1 DEP - GRV TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 180."
                    SIDC(8) = "MLR1 DEP - GRV TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 180."
                    SIDC(9) = "HAWFA1 DEP - OCEEN TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(10) = "HAWFA1 DEP - OCEEN TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(11) = "HAWFA1 DEP - OCEEN TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(12) = "KENED2 DEP - RENDR TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(13) = "KENED2 DEP - RENDR TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(14) = "KENED2 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(15) = "KENED2 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(16) = "HAWFA1 DEP - OCEEN TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(17) = "HAWFA1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "BEANS3 DEP - SPACE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(19) = "BEANS3 DEP - SEEKS TRANS. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "HAWFA1.NO TRANS - TERM HAWFA"
                    SID(1) = "MLR1.GRV - LH 180"
                    SID(2) = "N/A"
                    SID(3) = "C"
                    SID(4) = "MLR1.GRV - LH 180"
                    SID(5) = "MLR1.GRV - LH 180"
                    SID(6) = "MLR1.GRV - LH 180"
                    SID(7) = "MLR1.GRV - LH 180"
                    SID(8) = "MLR1.GRV - LH 180"
                    SID(9) = "HAWFA1.OCEEN"
                    SID(10) = "HAWFA1.OCEEN"
                    SID(11) = "HAWFA1.OCEEN"
                    SID(12) = "KENED2.RENDR"
                    SID(13) = "KENED2.RENDR"
                    SID(14) = "KENED2.DINER"
                    SID(15) = "KENED2.DINER"
                    SID(16) = "HAWFA1.OCEEN"
                    SID(17) = "HAWFA1.ANYMS"
                    SID(18) = "BEANS3.SPACE"
                    SID(19) = "BEANS3.SEEKS"

                    VECTOR(0) = "TURN RIGHT HDG 360"
                    VECTOR(1) = "TURN LEFT HDG 180"
                    VECTOR(2) = "TURN RIGHT HDG 360"
                    VECTOR(3) = "C"
                    VECTOR(4) = "TURN LEFT HDG 180"
                    VECTOR(5) = "TURN LEFT HDG 180"
                    VECTOR(6) = "TURN LEFT HDG 180"
                    VECTOR(7) = "TURN LEFT HDG 180"
                    VECTOR(8) = "TURN LEFT HDG 180"
                    VECTOR(9) = "TURN RIGHT HDG 360"
                    VECTOR(10) = "TURN RIGHT HDG 360"
                    VECTOR(11) = "TURN RIGHT HDG 360"
                    VECTOR(12) = "TURN RIGHT HDG 360"
                    VECTOR(13) = "TURN RIGHT HDG 360"
                    VECTOR(14) = "TURN RIGHT HDG 360"
                    VECTOR(15) = "TURN RIGHT HDG 360"
                    VECTOR(16) = "TURN RIGHT HDG 020"
                    VECTOR(17) = "TURN RIGHT HDG 020"
                    VECTOR(18) = "TURN RIGHT HDG 290"
                    VECTOR(19) = "TURN LEFT HDG 230"

                    VECTORC(0) = "RH 360"
                    VECTORC(1) = "LH 180"
                    VECTORC(2) = "RH 360"
                    VECTORC(3) = "C"
                    VECTORC(4) = "LH 180"
                    VECTORC(5) = "LH 180"
                    VECTORC(6) = "LH 180"
                    VECTORC(7) = "LH 180"
                    VECTORC(8) = "LH 180"
                    VECTORC(9) = "RH 360"
                    VECTORC(10) = "RH 360"
                    VECTORC(11) = "RH 360"
                    VECTORC(12) = "RH 360"
                    VECTORC(13) = "RH 360"
                    VECTORC(14) = "RH 360"
                    VECTORC(15) = "RH 360"
                    VECTORC(16) = "RH 020"
                    VECTORC(17) = "RH 020"
                    VECTORC(18) = "RH 290"
                    VECTORC(19) = "LH 230"
                ElseIf standardDepartureRunway = "07" Then
                    SIDC(0) = "HAWFA1 DEP - NO TRANS - TERMINATING AT HAWFA. DEP RWY " & standardDepartureRunway
                    SIDC(1) = "MLR1 DEP - GRV TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 340"
                    SIDC(2) = "N/A"
                    SIDC(3) = "C"
                    SIDC(4) = "MLR1 DEP - GRV TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 340."
                    SIDC(5) = "MLR1 DEP - GRV TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 340."
                    SIDC(6) = "MLR1 DEP - GRV TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 340."
                    SIDC(7) = "MLR1 DEP - GRV TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 340."
                    SIDC(8) = "MLR1 DEP - GRV TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 340."
                    SIDC(9) = "HAWFA1 DEP - OCEEN TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(10) = "HAWFA1 DEP - OCEEN TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(11) = "HAWFA1 DEP - OCEEN TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(12) = "KENED2 DEP - RENDR TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(13) = "KENED2 DEP - RENDR TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(14) = "KENED2 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(15) = "KENED2 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(16) = "HAWFA1 DEP - OCEEN TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(17) = "HAWFA1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "SAWPE1 DEP - SPACE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(19) = "SAWPE1 DEP - BEANS TRANS. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "HAWFA1.NO TRANS - TERM HAWFA"
                    SID(1) = "MLR1.GRV - LH 340"
                    SID(2) = "N/A"
                    SID(3) = "C"
                    SID(4) = "MLR1.GRV - LH 340"
                    SID(5) = "MLR1.GRV - LH 340"
                    SID(6) = "MLR1.GRV - LH 340"
                    SID(7) = "MLR1.GRV - LH 340"
                    SID(8) = "MLR1.GRV - LH 340"
                    SID(9) = "HAWFA1.OCEEN"
                    SID(10) = "HAWFA1.OCEEN"
                    SID(11) = "HAWFA1.OCEEN"
                    SID(12) = "KENED2.RENDR"
                    SID(13) = "KENED2.RENDR"
                    SID(14) = "KENED2.DINER"
                    SID(15) = "KENED2.DINER"
                    SID(16) = "HAWFA1.OCEEN"
                    SID(17) = "HAWFA1.ANYMS"
                    SID(18) = "SAWPE1.SPACE"
                    SID(19) = "SAWPE.BEANS"

                    VECTOR(0) = "FLY RUNWAY HDG"
                    VECTOR(1) = "TURN LEFT HDG 350"
                    VECTOR(2) = "FLY RUNWAY HDG"
                    VECTOR(3) = "C"
                    VECTOR(4) = "FLY RUNWAY HDG"
                    VECTOR(5) = "FLY RUNWAY HDG"
                    VECTOR(6) = "FLY RUNWAY HDG"
                    VECTOR(7) = "FLY RUNWAY HDG"
                    VECTOR(8) = "FLY RUNWAY HDG"
                    VECTOR(9) = "FLY RUNWAY HDG"
                    VECTOR(10) = "FLY RUNWAY HDG"
                    VECTOR(11) = "FLY RUNWAY HDG"
                    VECTOR(12) = "TURN LEFT HDG 360"
                    VECTOR(13) = "TURN LEFT HDG 360"
                    VECTOR(14) = "FLY RUNWAY HDG"
                    VECTOR(15) = "FLY RUNWAY HDG"
                    VECTOR(16) = "FLY RUNWAY HDG"
                    VECTOR(17) = "FLY RUNWAY HDG"
                    VECTOR(18) = "TURN LEFT HDG 350"
                    VECTOR(19) = "TURN LEFT HDG 340"

                    VECTORC(0) = "RWY HDG"
                    VECTORC(1) = "LH 350"
                    VECTORC(2) = "RWY HDG"
                    VECTORC(3) = "C"
                    VECTORC(4) = "RWY HDG"
                    VECTORC(5) = "RWY HDG"
                    VECTORC(6) = "RWY HDG"
                    VECTORC(7) = "RWY HDG"
                    VECTORC(8) = "RWY HDG"
                    VECTORC(9) = "RWY HDG"
                    VECTORC(10) = "RWY HDG"
                    VECTORC(11) = "RWY HDG"
                    VECTORC(12) = "LH 360"
                    VECTORC(13) = "LH 360"
                    VECTORC(14) = "RWY HDG"
                    VECTORC(15) = "RWY HDG"
                    VECTORC(16) = "RWY HDG"
                    VECTORC(17) = "RWY HDG"
                    VECTORC(18) = "LH 350"
                    VECTORC(19) = "LH 340"
                End If
                centreFreq = "124.850MHz."
            ElseIf airport = "ILAR" And (standardDepartureRunway = "06" Or standardDepartureRunway = "24") Then
                airportValidated = True
                If standardDepartureRunway = "24" Then
                    SIDC(0) = "GRASS1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(1) = "GRASS1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(2) = "GRASS1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(3) = "GRASS1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "C"
                    SIDC(5) = "N/A"
                    SIDC(6) = "N/A"
                    SIDC(7) = "N/A"
                    SIDC(8) = "N/A"
                    SIDC(9) = "GRASS1 DEP - RENTS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(10) = "GRASS1 DEP - RENTS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(11) = "GRASS1 DEP - RENTS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(12) = "GRASS1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(13) = "GRASS1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(14) = "GRASS1 DEP - RENTS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(15) = "GRASS1 DEP - RENTS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(16) = "GRASS1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(17) = "GRASS1 DEP - RENTS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "ODOKU1 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(19) = "ODOKU1 DEP. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "GRASS1.ANYMS"
                    SID(1) = "GRASS1.ANYMS"
                    SID(2) = "GRASS1.ANYMS"
                    SID(3) = "GRASS1.ANYMS"
                    SID(4) = "C"
                    SID(5) = "N/A"
                    SID(6) = "N/A"
                    SID(7) = "N/A"
                    SID(8) = "N/A"
                    SID(9) = "GRASS1.RENTS"
                    SID(10) = "GRASS1.RENTS"
                    SID(11) = "GRASS1.RENTS"
                    SID(12) = "GRASS1.ANYMS"
                    SID(13) = "GRASS1.ANYMS"
                    SID(14) = "GRASS1.RENTS"
                    SID(15) = "GRASS1.RENTS"
                    SID(16) = "GRASS1.ANYMS"
                    SID(17) = "GRASS1.RENTS"
                    SID(18) = "ODOKU1"
                    SID(19) = "ODOKU1"

                    VECTOR(0) = "TURN LEFT HDG 310"
                    VECTOR(1) = "TURN LEFT HDG 310"
                    VECTOR(2) = "TURN LEFT HDG 310"
                    VECTOR(3) = "TURN LEFT HDG 310"
                    VECTOR(4) = "C"
                    VECTOR(5) = "TURN LEFT HDG 040"
                    VECTOR(6) = "TURN LEFT HDG 040"
                    VECTOR(7) = "TURN LEFT HDG 040"
                    VECTOR(8) = "TURN LEFT HDG 040"
                    VECTOR(9) = "TURN LEFT HDG 040"
                    VECTOR(10) = "TURN LEFT HDG 040"
                    VECTOR(11) = "TURN LEFT HDG 040"
                    VECTOR(12) = "TURN LEFT HDG 360"
                    VECTOR(13) = "TURN LEFT HDG 360"
                    VECTOR(14) = "TURN LEFT HDG 040"
                    VECTOR(15) = "TURN LEFT HDG 040"
                    VECTOR(16) = "TURN LEFT HDG 360"
                    VECTOR(17) = "TURN LEFT HDG 040"
                    VECTOR(18) = "TURN LEFT HDG 310"
                    VECTOR(19) = "TURN LEFT HDG 310"

                    VECTORC(0) = "LH 310"
                    VECTORC(1) = "LH 310"
                    VECTORC(2) = "LH 310"
                    VECTORC(3) = "LH 310"
                    VECTORC(4) = "C"
                    VECTORC(5) = "LH 040"
                    VECTORC(6) = "LH 040"
                    VECTORC(7) = "LH 040"
                    VECTORC(8) = "LH 040"
                    VECTORC(9) = "LH 040"
                    VECTORC(10) = "LH 040"
                    VECTORC(11) = "LH 040"
                    VECTORC(12) = "LH 360"
                    VECTORC(13) = "LH 360"
                    VECTORC(14) = "LH 040"
                    VECTORC(15) = "LH 040"
                    VECTORC(16) = "LH 360"
                    VECTORC(17) = "LH 040"
                    VECTORC(18) = "LH 310"
                    VECTORC(19) = "LH 310"
                ElseIf departureRunway = "06" Then
                    SIDC(0) = "RENTS1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(1) = "RENTS1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(2) = "RENTS1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(3) = "RENTS1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "C"
                    SIDC(5) = "N/A"
                    SIDC(6) = "N/A"
                    SIDC(7) = "N/A"
                    SIDC(8) = "N/A"
                    SIDC(9) = "RENTS1 DEP - JUSTY TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(10) = "RENTS1 DEP - JUSTY TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(11) = "RENTS1 DEP - JUSTY TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(12) = "RENTS1 DEP - CAWZE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(13) = "RENTS1 DEP - CAWZE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(14) = "RENTS1 DEP - JUSTY TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(15) = "RENTS1 DEP - JUSTY TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(16) = "RENTS1 DEP - CAWZE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(17) = "RENTS1 DEP - NO TRANS - TERMINATNIG AT RENTS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "RENTS1 DEP - ANYMS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(19) = "ODOKU1 DEP. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "RENTS1.ANYMS"
                    SID(1) = "RENTS1.ANYMS"
                    SID(2) = "RENTS1.ANYMS"
                    SID(3) = "RENTS1.ANYMS"
                    SID(4) = "C"
                    SID(5) = "N/A"
                    SID(6) = "N/A"
                    SID(7) = "N/A"
                    SID(8) = "N/A"
                    SID(9) = "RENTS1.JUSTY"
                    SID(10) = "RENTS1.JUSTY"
                    SID(11) = "RENTS1.JUSTY"
                    SID(12) = "RENTS1.CAWZE"
                    SID(13) = "RENTS1.CAWZE"
                    SID(14) = "RENTS1.JUSTY"
                    SID(15) = "RENTS1.JUSTY"
                    SID(16) = "RENTS1.CAWZE"
                    SID(17) = "RENTS1.NO TRANS - TERM RENTS"
                    SID(18) = "RENTS1.ANYMS"
                    SID(19) = "ODOKU1"

                    VECTOR(0) = "TURN RIGHT HDG 280"
                    VECTOR(1) = "TURN RIGHT HDG 280"
                    VECTOR(2) = "TURN RIGHT HDG 280"
                    VECTOR(3) = "TURN RIGHT HDG 280"
                    VECTOR(4) = "C"
                    VECTOR(5) = "TURN LEFT HDG 180"
                    VECTOR(6) = "TURN LEFT HDG 180"
                    VECTOR(7) = "TURN LEFT HDG 180"
                    VECTOR(8) = "TURN LEFT HDG 180"
                    VECTOR(9) = "TURN RIGHT HDG 020"
                    VECTOR(10) = "TURN RIGHT HDG 020"
                    VECTOR(11) = "TURN RIGHT HDG 020"
                    VECTOR(12) = "TURN RIGHT HDG 360"
                    VECTOR(13) = "TURN RIGHT HDG 360"
                    VECTOR(14) = "TURN RIGHT HDG 360"
                    VECTOR(15) = "TURN RIGHT HDG 360"
                    VECTOR(16) = "TURN RIGHT HDG 360"
                    VECTOR(17) = "TURN RIGHT HDG 030"
                    VECTOR(18) = "TURN RIGHT HDG 280"
                    VECTOR(19) = "FLY RUNWAY HDG"

                    VECTORC(0) = "RH 280"
                    VECTORC(1) = "RH 280"
                    VECTORC(2) = "RH 280"
                    VECTORC(3) = "RH 280"
                    VECTORC(4) = "C"
                    VECTORC(5) = "LH 180"
                    VECTORC(6) = "LH 180"
                    VECTORC(7) = "LH 180"
                    VECTORC(8) = "LH 180"
                    VECTORC(9) = "RH 020"
                    VECTORC(10) = "RH 020"
                    VECTORC(11) = "RH 020"
                    VECTORC(12) = "RH 360"
                    VECTORC(13) = "RH 360"
                    VECTORC(14) = "RH 360"
                    VECTORC(15) = "RH 360"
                    VECTORC(16) = "RH 360"
                    VECTORC(17) = "RH 030"
                    VECTORC(18) = "RH 280"
                    VECTORC(19) = "RWY HDG"
                End If
                centreFreq = "126.300MHz."
            ElseIf airport = "IPAP" And (standardDepartureRunway = "17" Or standardDepartureRunway = "35") Then
                airportValidated = True
                If standardDepartureRunway = "17" Then
                    SIDC(0) = "KIN1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(1) = "KIN1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(2) = "KIN1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(3) = "KIN1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "N/A"
                    SIDC(5) = "C"
                    SIDC(6) = "N/A"
                    SIDC(7) = "N/A"
                    SIDC(8) = "N/A"
                    SIDC(9) = "KIN1 DEP - JUSTY TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(10) = "KIN1 DEP - JUSTY TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(11) = "KIN1 DEP - JUSTY TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(12) = "KIN1 DEP - DEL TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(13) = "KIN1 DEP - DEL TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(14) = "KIN1 DEP - DEL TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(15) = "KIN1 DEP - DEL TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(16) = "KIN1 DEP - DEL TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(17) = "KIN1 DEP - ANYMS TRANS - TERMINATING AT RENTS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "KIN1 DEP - GRASS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(19) = "KIN1 DEP - GRASS TRANS. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "KIN1.ANYMS"
                    SID(1) = "KIN1.ANYMS"
                    SID(2) = "KIN1.ANYMS"
                    SID(3) = "KIN1.ANYMS"
                    SID(4) = "N/A"
                    SID(5) = "C"
                    SID(6) = "N/A"
                    SID(7) = "N/A"
                    SID(8) = "N/A"
                    SID(9) = "KIN1.JUSTY"
                    SID(10) = "KIN1.JUSTY"
                    SID(11) = "KIN1.JUSTY"
                    SID(12) = "KIN1.DEL"
                    SID(13) = "KIN1.DEL"
                    SID(14) = "KIN1.DEL"
                    SID(15) = "KIN1.DEL"
                    SID(16) = "KIN1.DEL"
                    SID(17) = "KIN1.ANYMS - TERM RENTS"
                    SID(18) = "KIN1.GRASS"
                    SID(19) = "KIN1.GRASS"

                    VECTOR(0) = "TURN RIGHT HDG 240"
                    VECTOR(1) = "TURN RIGHT HDG 240"
                    VECTOR(2) = "TURN RIGHT HDG 240"
                    VECTOR(3) = "TURN RIGHT HDG 240"
                    VECTOR(4) = "TURN LEFT HDG 040"
                    VECTOR(5) = "C"
                    VECTOR(6) = "FLY RUNWAY HDG"
                    VECTOR(7) = "TURN LEFT HDG 020"
                    VECTOR(8) = "FLY RUNWAY HDG"
                    VECTOR(9) = "TURN LEFT HDG 040"
                    VECTOR(10) = "TURN LEFT HDG 040"
                    VECTOR(11) = "TURN LEFT HDG 040"
                    VECTOR(12) = "TURN LEFT HDG 040"
                    VECTOR(13) = "TURN LEFT HDG 040"
                    VECTOR(14) = "TURN LEFT HDG 020"
                    VECTOR(15) = "TURN LEFT HDG 020"
                    VECTOR(16) = "TURN LEFT HDG 020"
                    VECTOR(17) = "TURN LEFT HDG 020"
                    VECTOR(18) = "TURN RIGHT HDG 240"
                    VECTOR(19) = "TURN RIGHT HDG 240"

                    VECTORC(0) = "RH 240"
                    VECTORC(1) = "RH 240"
                    VECTORC(2) = "RH 240"
                    VECTORC(3) = "RH 240"
                    VECTORC(4) = "LH 040"
                    VECTORC(5) = "C"
                    VECTORC(6) = "RWY HDG"
                    VECTORC(7) = "LH 020"
                    VECTORC(8) = "RWY HDG"
                    VECTORC(9) = "LH 040"
                    VECTORC(10) = "LH 040"
                    VECTORC(11) = "LH 040"
                    VECTORC(12) = "LH 040"
                    VECTORC(13) = "LH 040"
                    VECTORC(14) = "LH 020"
                    VECTORC(15) = "LH 020"
                    VECTORC(16) = "LH 020"
                    VECTORC(17) = "LH 020"
                    VECTORC(18) = "RH 240"
                    VECTORC(19) = "RH 240"
                ElseIf standardDepartureRunway = "35" Then
                    SIDC(0) = "KIN1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(1) = "KIN1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(2) = "KIN1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(3) = "KIN1 DEP - ANYMS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "N/A"
                    SIDC(5) = "C"
                    SIDC(6) = "N/A"
                    SIDC(7) = "N/A"
                    SIDC(8) = "N/A"
                    SIDC(9) = "KIN1 DEP - JUSTY TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(10) = "KIN1 DEP - JUSTY TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(11) = "KIN1 DEP - JUSTY TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(12) = "KIN1 DEP - DEL TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(13) = "KIN1 DEP - DEL TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(14) = "KIN1 DEP - DEL TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(15) = "KIN1 DEP - DEL TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(16) = "KIN1 DEP - DEL TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(17) = "KIN1 DEP - ANYMS TRANS - TERMINATING AT RENTS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "KIN1 DEP - GRASS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(19) = "KIN1 DEP - GRASS TRANS. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "KIN1.ANYMS"
                    SID(1) = "KIN1.ANYMS"
                    SID(2) = "KIN1.ANYMS"
                    SID(3) = "KIN1.ANYMS"
                    SID(4) = "N/A"
                    SID(5) = "C"
                    SID(6) = "N/A"
                    SID(7) = "N/A"
                    SID(8) = "N/A"
                    SID(9) = "KIN1.JUSTY"
                    SID(10) = "KIN1.JUSTY"
                    SID(11) = "KIN1.JUSTY"
                    SID(12) = "KIN1.DEL"
                    SID(13) = "KIN1.DEL"
                    SID(14) = "KIN1.DEL"
                    SID(15) = "KIN1.DEL"
                    SID(16) = "KIN1.DEL"
                    SID(17) = "KIN1.ANYMS - TERM RENTS"
                    SID(18) = "KIN1.GRASS"
                    SID(19) = "KIN1.GRASS"

                    VECTOR(0) = "TURN LEFT HDG 300"
                    VECTOR(1) = "TURN LEFT HDG 300"
                    VECTOR(2) = "TURN LEFT HDG 300"
                    VECTOR(3) = "TURN LEFT HDG 300"
                    VECTOR(4) = "FLY RUNWAY HDG"
                    VECTOR(5) = "C"
                    VECTOR(6) = "TURN RIGHT HDG 130"
                    VECTOR(7) = "TURN RIGHT HDG 130"
                    VECTOR(8) = "TURN RIGHT HDG 130"
                    VECTOR(9) = "FLY RUNWAY HDG"
                    VECTOR(10) = "FLY RUNWAY HDG"
                    VECTOR(11) = "FLY RUNWAY HDG"
                    VECTOR(12) = "FLY RUNWAY HDG"
                    VECTOR(13) = "FLY RUNWAY HDG"
                    VECTOR(14) = "FLY RUNWAY HDG"
                    VECTOR(15) = "FLY RUNWAY HDG"
                    VECTOR(16) = "FLY RUNWAY HDG"
                    VECTOR(17) = "FLY RUNWAY HDG"
                    VECTOR(18) = "TURN LEFT HDG 280"
                    VECTOR(19) = "TURN LEFT HDG 280"

                    VECTORC(0) = "LH 300"
                    VECTORC(1) = "LH 300"
                    VECTORC(2) = "LH 300"
                    VECTORC(3) = "LH 300"
                    VECTORC(4) = "RWY HDG"
                    VECTORC(5) = "C"
                    VECTORC(6) = "RH 130"
                    VECTORC(7) = "RH 130"
                    VECTORC(8) = "RH 130"
                    VECTORC(9) = "RWY HDG"
                    VECTORC(10) = "RWY HDG"
                    VECTORC(11) = "RWY HDG"
                    VECTORC(12) = "RWY HDG"
                    VECTORC(13) = "RWY HDG"
                    VECTORC(14) = "RWY HDG"
                    VECTORC(15) = "RWY HDG"
                    VECTORC(16) = "RWY HDG"
                    VECTORC(17) = "RWY HDG"
                    VECTORC(18) = "LH 280"
                    VECTORC(19) = "LH 280"
                End If
                centreFreq = "126.300MHz."
            ElseIf airport = "IIAB" And (standardDepartureRunway = "09L" Or standardDepartureRunway = "09R" Or standardDepartureRunway = "27L" Or standardDepartureRunway = "27R") Then
                airportValidated = True
                If standardDepartureRunway = "27L" Or standardDepartureRunway = "27R" Then
                    SIDC(0) = "MCL1 DEP - JAMSI TRANS VIA CAN - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 240."
                    SIDC(1) = "MCL1 DEP - JAMSI TRANS VIA CAN - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 240."
                    SIDC(2) = "MCL1 DEP - JAMSI TRANS VIA CAN - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 240."
                    SIDC(3) = "MCL1 DEP - JAMSI TRANS VIA CAN - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 240."
                    SIDC(4) = "N/A"
                    SIDC(5) = "N/A"
                    SIDC(6) = "C"
                    SIDC(7) = "N/A"
                    SIDC(8) = "N/A"
                    SIDC(9) = "MCL1 DEP - JACKI TRANS VIA PFO - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 180."
                    SIDC(10) = "MCL1 DEP - JACKI TRANS VIA PFO - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 180."
                    SIDC(11) = "MCL1 DEP - JACKI TRANS VIA PFO - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 180."
                    SIDC(12) = "MCL1 DEP - ANYMS TRANS VIA CAN - AFT DEP RWY " & standardDepartureRunway & " TURNLEFT HDG 240."
                    SIDC(13) = "MCL1 DEP - ANYMS TRANS VIA CAN - AFT DEP RWY " & standardDepartureRunway & " TURNLEFT HDG 240."
                    SIDC(14) = "MCL1 DEP - ANYMS TRANS VIA CAN - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 240."
                    SIDC(15) = "MCL1 DEP - ANYMS TRANS VIA CAN - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 240."
                    SIDC(16) = "MCL1 DEP - ANYMS TRANS VIA CAN - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 240."
                    SIDC(17) = "MCL1 DEP - ANYMS TRANS VIA CAN - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 240."
                    SIDC(18) = "MCL1 DEP - ANYMS TRANS VIA CAN - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 240."
                    SIDC(19) = "MCL1 DEP - CAN TRANS - AFT DEP RWY " & standardDepartureRunway & " FLY STRIGHT AHEAD DIRECT CAN."

                    SID(0) = "MCL1.JAMSI VIA CAN - LH 240"
                    SID(1) = "MCL1.JAMSI VIA CAN - LH 240"
                    SID(2) = "MCL1.JAMSI VIA CAN - LH 240"
                    SID(3) = "MCL1.JAMSI VIA CAN - LH 240"
                    SID(4) = "N/A"
                    SID(5) = "N/A"
                    SID(6) = "C"
                    SID(7) = "N/A"
                    SID(8) = "N/A"
                    SID(9) = "MCL1.JACKI VIA PFO - LH 180"
                    SID(10) = "MCL1.JACKI VIA PFO - LH 180"
                    SID(11) = "MCL1.JACKI VIA PFO LH 180"
                    SID(12) = "MCL1.ANYMS VIA CAN - LH 240"
                    SID(13) = "MCL1.ANYMS VIA CAN - LH 240"
                    SID(14) = "MCL1.ANYMS VIA CAN - LH 240"
                    SID(15) = "MCL1.ANYMS VIA CAN - LH 240"
                    SID(16) = "MCL1.ANYMS VIA CAN - LH 240"
                    SID(17) = "MCL1.ANYMS VIA CAN - LH 240"
                    SID(18) = "MCL1.ANYMS VIA CAN - LH 240"
                    SID(19) = "MCL1.CAN - STRT DCT CAN"

                    VECTOR(0) = "TURN RIGHT HDG 330"
                    VECTOR(1) = "TURN RIGHT HDG 330"
                    VECTOR(2) = "TURN RIGHT HDG 330"
                    VECTOR(3) = "TURN RIGHT HDG 330"
                    VECTOR(4) = "FLY RUNWAY HDG"
                    VECTOR(5) = "TURN LEFT HDG 130"
                    VECTOR(6) = "C"
                    VECTOR(7) = "FLY RUNWAY HDG"
                    VECTOR(8) = "FLY RUNWAY HDG"
                    VECTOR(9) = "TURN RIGHT HDG 360"
                    VECTOR(10) = "TURN RIGHT HDG 360"
                    VECTOR(11) = "TURN RIGHT HDG 360"
                    VECTOR(12) = "TURN RIGHT HDG 360"
                    VECTOR(13) = "TURN RIGHT HDG 360"
                    VECTOR(14) = "TURN RIGHT HDG 360"
                    VECTOR(15) = "TURN RIGHT HDG 360"
                    VECTOR(16) = "TURN RIGHT HDG 360"
                    VECTOR(17) = "TURN RIGHT HDG 360"
                    VECTOR(18) = "TURN RIGHT HDG 330"
                    VECTOR(19) = "FLY RUNWAY HDG"

                    VECTORC(0) = "RH 330"
                    VECTORC(1) = "RH 330"
                    VECTORC(2) = "RH 330"
                    VECTORC(3) = "RH 330"
                    VECTORC(4) = "RWY HDG"
                    VECTORC(5) = "LH 130"
                    VECTORC(6) = "C"
                    VECTORC(7) = "RWY HDG"
                    VECTORC(8) = "RWY HDG"
                    VECTORC(9) = "RH 360"
                    VECTORC(10) = "RH 360"
                    VECTORC(11) = "RH 360"
                    VECTORC(12) = "RH 360"
                    VECTORC(13) = "RH 360"
                    VECTORC(14) = "RH 360"
                    VECTORC(15) = "RH 360"
                    VECTORC(16) = "RH 360"
                    VECTORC(17) = "RH 360"
                    VECTORC(18) = "RH 330"
                    VECTORC(19) = "RWY HDG"
                ElseIf standardDepartureRunway = "09R" Or standardDepartureRunway = "09L" Then
                    SIDC(0) = "MCL1 DEP - RENTS TRANS VIA KIN - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SIDC(1) = "MCL1 DEP - RENTS TRANS VIA KIN - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SIDC(2) = "MCL1 DEP - RENTS TRANS VIA KIN - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SIDC(3) = "MCL1 DEP - RENTS TRANS VIA KIN - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SIDC(4) = "N/A"
                    SIDC(5) = "N/A"
                    SIDC(6) = "C"
                    SIDC(7) = "N/A"
                    SIDC(8) = "N/A"
                    SIDC(9) = "MCL1 DEP - JACKI TRANS VIA PFO - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT DIRECT PFO."
                    SIDC(10) = "MCL1 DEP - JACKI TRANS VIA PFO - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT DIRECT PFO."
                    SIDC(11) = "MCL1 DEP - JACKI TRANS VIA PFO - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT DIRECT PFO."
                    SIDC(12) = "MCL1 DEP - RENTS TRANS VIA KIN - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SIDC(13) = "MCL1 DEP - RENTS TRANS VIA KIN - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SIDC(14) = "MCL1 DEP - RENTS TRANS VIA KIN - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SIDC(15) = "MCL1 DEP - RENTS TRANS VIA KIN - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SIDC(16) = "MCL1 DEP - RENTS TRANS VIA KIN - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SIDC(17) = "MCL1 DEP - RENTS TRANS VIA KIN - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SIDC(18) = "MCL1 DEP - RENTS TRANS VIA KIN - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SIDC(19) = "MCL1 DEP - DIR TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT HDG 210."

                    SID(0) = "MCL1.RENTS VIA KIN - RWY HDG"
                    SID(1) = "MCL1.RENTS VIA KIN -RWY HDG"
                    SID(2) = "MCL1.RENTS VIA KIN -RWY HDG"
                    SID(3) = "MCL1.RENTS VIA KIN -RWY HDG"
                    SID(4) = "N/A"
                    SID(5) = "N/A"
                    SID(6) = "C"
                    SID(7) = "N/A"
                    SID(8) = "N/A"
                    SID(9) = "MCL1.JACKI VIA PFO - L DCT PFO"
                    SID(10) = "MCL1.JACKI VIA PFO - DCT PFO"
                    SID(11) = "MCL1.JACKI VIA PFO - DCT PFO"
                    SID(12) = "MCL1.RENTS VIA KIN - RWY HDG"
                    SID(13) = "MCL1.RENTS VIA KIN - RWY HDG"
                    SID(14) = "MCL1.RENTS VIA KIN - RWY HDG"
                    SID(15) = "MCL1.RENTS VIA KIN - RWY HDG"
                    SID(16) = "MCL1.RENTS VIA KIN - RWY HDG"
                    SID(17) = "MCL1.RENTS VIA KIN - RWY HDG"
                    SID(18) = "MCL1.RENTS VIA KIN - RWY HDG"
                    SID(19) = "MCL1.DIR - RH 210"

                    VECTOR(0) = "TURN LEFT HDG 080"
                    VECTOR(1) = "TURN LEFT HDG 080"
                    VECTOR(2) = "TURN LEFT HDG 080"
                    VECTOR(3) = "TURN LEFT HDG 080"
                    VECTOR(4) = "TURN LEFT HDG 080"
                    VECTOR(5) = "FLY RUNWAY HDG"
                    VECTOR(6) = "C"
                    VECTOR(7) = "TURN LEFT HDG 080"
                    VECTOR(8) = "FLY RUNWAY HDG"
                    VECTOR(9) = "TURN LEFT HDG 080"
                    VECTOR(10) = "TURN LEFT HDG 080"
                    VECTOR(11) = "TURN LEFT HDG 080"
                    VECTOR(12) = "TURN LEFT HDG 080"
                    VECTOR(13) = "TURN LEFT HDG 080"
                    VECTOR(14) = "TURN LEFT HDG 080"
                    VECTOR(15) = "TURN LEFT HDG 080"
                    VECTOR(16) = "TURN LEFT HDG 080"
                    VECTOR(17) = "TURN LEFT HDG 080"
                    VECTOR(18) = "TURN LEFT HDG 080"
                    VECTOR(19) = "TURN RIGHT HDG 250"

                    VECTORC(0) = "LH 080"
                    VECTORC(1) = "LH 080"
                    VECTORC(2) = "LH 080"
                    VECTORC(3) = "LH 080"
                    VECTORC(4) = "LH 080"
                    VECTORC(5) = "RWY HDG"
                    VECTORC(6) = "C"
                    VECTORC(7) = "LH 080"
                    VECTORC(8) = "RWY HDG"
                    VECTORC(9) = "LH 080"
                    VECTORC(10) = "LH 080"
                    VECTORC(11) = "LH 080"
                    VECTORC(12) = "LH 080"
                    VECTORC(13) = "LH 080"
                    VECTORC(14) = "LH 080"
                    VECTORC(15) = "LH 080"
                    VECTORC(16) = "LH 080"
                    VECTORC(17) = "LH 080"
                    VECTORC(18) = "LH 080"
                    VECTORC(19) = "RH 250"
                End If
                centreFreq = "126.300MHz."
            ElseIf airport = "ITKO" And (standardDepartureRunway = "13" Or standardDepartureRunway = "31" Or standardDepartureRunway = "20") Then
                airportValidated = True
                If standardDepartureRunway = "13" Then
                    SIDC(0) = "ONDER1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(1) = "ONDER1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(2) = "ONDER1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(3) = "ONDER1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "ONDER1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(5) = "ONDER1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(6) = "ONDER1 DEP - DINER TRAMS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(7) = "ONDER1 DEP - DINER TRAMS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(8) = "ONDER1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(9) = "TOKYO1 DEP - KNIFE TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT DIRECT KNIFE."
                    SIDC(10) = "TOKYO1 DEP - KNIFE TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT DIRECT KNIFE."
                    SIDC(11) = "TOKYO1 DEP - KNIFE TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT DIRECT KNIFE."
                    SIDC(12) = "C"
                    SIDC(13) = "N/A"
                    SIDC(14) = "TOKYO1 DEP - KNIFE TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT DIRECT KNIFE."
                    SIDC(15) = "TOKYO1 DEP - KNIFE TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT DIRECT KNIFE."
                    SIDC(16) = "TOKYO1 DEP - ONDER TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT DIRECT ONDER."
                    SIDC(17) = "ONDER1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "TOKYO1 DEP - ASTRO TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT DIRECT ASTRO."
                    SIDC(19) = "ONDER1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "ONDER1.PROBE"
                    SID(1) = "ONDER1.PROBE"
                    SID(2) = "ONDER1.PROBE"
                    SID(3) = "ONDER1.PROBE"
                    SID(4) = "ONDER1.DINER"
                    SID(5) = "ONDER1.DINER"
                    SID(6) = "ONDER1.DINER"
                    SID(7) = "ONDER1.DINER"
                    SID(8) = "ONDER1.DINER"
                    SID(9) = "TOKYO1.KNIFE - R DCT KNIFE"
                    SID(10) = "TOKYO1.KNIFE - R DCT KNIFE"
                    SID(11) = "TOKYO1.KNIFE - R DCT KNIFE"
                    SID(12) = "C"
                    SID(13) = "N/A"
                    SID(14) = "TOKYO1.KNIFE - R DCT KNIFE"
                    SID(15) = "TOKYO1.KNIFE - R DCT KNIFE"
                    SID(16) = "TOKYO1.ONDER - R DCT ONDER"
                    SID(17) = "ONDER1.DINER"
                    SID(18) = "TOKYO1.ASTRO - R DCT ASTRO"
                    SID(19) = "ONDER1.PROBE"

                    VECTOR(0) = "TURN RIGHT HDG 180"
                    VECTOR(1) = "TURN RIGHT HDG 180"
                    VECTOR(2) = "TURN RIGHT HDG 180"
                    VECTOR(3) = "TURN RIGHT HDG 180"
                    VECTOR(4) = "FLY RUNWAY HDG"
                    VECTOR(5) = "FLY RUNWAY HDG"
                    VECTOR(6) = "FLY RUNWAY HDG"
                    VECTOR(7) = "FLY RUNWAY HDG"
                    VECTOR(8) = "FLY RUNWAY HDG"
                    VECTOR(9) = "FLY RUNWAY HDG"
                    VECTOR(10) = "FLY RUNWAY HDG"
                    VECTOR(11) = "FLY RUNWAY HDG"
                    VECTOR(12) = "C"
                    VECTOR(13) = "TURN LEFT HDG 360"
                    VECTOR(14) = "TURN LEFT HDG 090"
                    VECTOR(15) = "TURN LEFT HDG 090"
                    VECTOR(16) = "TURN RIGHT HDG 180"
                    VECTOR(17) = "TURN RIGHT HDG 180"
                    VECTOR(18) = "TURN RIGHT HDG 220"
                    VECTOR(19) = "TURN RIGHT HDG 240"


                    VECTORC(0) = "RH 180"
                    VECTORC(1) = "RH 180"
                    VECTORC(2) = "RH 180"
                    VECTORC(3) = "RH 180"
                    VECTORC(4) = "RWY HDG"
                    VECTORC(5) = "RWY HDG"
                    VECTORC(6) = "RWY HDG"
                    VECTORC(7) = "RWY HDG"
                    VECTORC(8) = "RWY HDG"
                    VECTORC(9) = "RWY HDG"
                    VECTORC(10) = "RWY HDG"
                    VECTORC(11) = "RWY HDG"
                    VECTORC(12) = "C"
                    VECTORC(13) = "LH 360"
                    VECTORC(14) = "LH 090"
                    VECTORC(15) = "LH 090"
                    VECTORC(16) = "RH 180"
                    VECTORC(17) = "RH 180"
                    VECTORC(18) = "RH 220"
                    VECTORC(19) = "RH 240"
                ElseIf standardDepartureRunway = "20" Then
                    SIDC(0) = "ONDER1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(1) = "ONDER1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(2) = "ONDER1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(3) = "ONDER1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "ONDER1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(5) = "ONDER1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(6) = "ONDER1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(7) = "ONDER1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(8) = "ONDER1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(9) = "TOKYO1 DEP - KNIFE TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT DIRECT KNIFE."
                    SIDC(10) = "TOKYO1 DEP - KNIFE TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT DIRECT KNIFE."
                    SIDC(11) = "TOKYO1 DEP - KNIFE TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT DIRECT KNIFE."
                    SIDC(12) = "C"
                    SIDC(13) = "N/A"
                    SIDC(14) = "HONDA1 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(15) = "HONDA1 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(16) = "TOKYO1 DEP - ONDER TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT DIRECT ONDER."
                    SIDC(17) = "ONDER1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "TOKYO1 DEP - ASTRO TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT DIRECT ASTRO."
                    SIDC(19) = "ONDER1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "ONDER1.PROBE"
                    SID(1) = "ONDER1.PROBE"
                    SID(2) = "ONDER1.PROBE"
                    SID(3) = "ONDER1.PROBE"
                    SID(4) = "ONDER1.DINER"
                    SID(5) = "ONDER1.DINER"
                    SID(6) = "ONDER1.DINER"
                    SID(7) = "ONDER1.DINER"
                    SID(8) = "ONDER1.DINER"
                    SID(9) = "TOKYO1.KNIFE - L DCT KNIFE"
                    SID(10) = "TOKYO1.KNIFE - L DCT KNIFE"
                    SID(11) = "TOKYO1.KNIFE - L DCT KNIFE"
                    SID(12) = "C"
                    SID(13) = "N/A"
                    SID(14) = "HONDA1"
                    SID(15) = "HONDA1"
                    SID(16) = "TOKYO1.ONDER - L DCT ONDER"
                    SID(17) = "ONDER1.DINER"
                    SID(18) = "TOKYO1.ASTRO - R DCT ASTRO"
                    SID(19) = "ONDER1.PROBE"

                    VECTOR(0) = "FLY RUNWAY HDG"
                    VECTOR(1) = "FLY RUNWAY HDG"
                    VECTOR(2) = "FLY RUNWAY HDG"
                    VECTOR(3) = "FLY RUNWAY HDG"
                    VECTOR(4) = "FLY RUNWAY HDG"
                    VECTOR(5) = "FLY RUNWAY HDG"
                    VECTOR(6) = "FLY RUNWAY HDG"
                    VECTOR(7) = "FLY RUNWAY HDG"
                    VECTOR(8) = "FLY RUNWAY HDG"
                    VECTOR(9) = "TURN LEFT HDG 110"
                    VECTOR(10) = "TURN LEFT HDG 110"
                    VECTOR(11) = "TURN LEFT HDG 110"
                    VECTOR(12) = "C"
                    VECTOR(13) = "TURN RIGHT HDG 320"
                    VECTOR(14) = "TURN LEFT HDG 090"
                    VECTOR(15) = "TURN LEFT HDG 090"
                    VECTOR(16) = "TURN LEFT HDG 160"
                    VECTOR(17) = "TURN LEFT HDG 170"
                    VECTOR(18) = "FLY RUNWAY HDG"
                    VECTOR(19) = "TURN RIGHT HDG 250"

                    VECTORC(0) = "RWY HDG"
                    VECTORC(1) = "RWY HDG"
                    VECTORC(2) = "RWY HDG"
                    VECTORC(3) = "RWY HDG"
                    VECTORC(4) = "RWY HDG"
                    VECTORC(5) = "RWY HDG"
                    VECTORC(6) = "RWY HDG"
                    VECTORC(7) = "RWY HDG"
                    VECTORC(8) = "RWY HDG"
                    VECTORC(9) = "LH 110"
                    VECTORC(10) = "LH 110"
                    VECTORC(11) = "LH 110"
                    VECTORC(12) = "C"
                    VECTORC(13) = "RH 320"
                    VECTORC(14) = "LH 090"
                    VECTORC(15) = "LH 090"
                    VECTORC(16) = "LH 160"
                    VECTORC(17) = "LH 170"
                    VECTORC(18) = "RWY HDG"
                    VECTORC(19) = "RH 250"
                ElseIf standardDepartureRunway = "31" Then
                    SIDC(0) = "ASTRO1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(1) = "ASTRO1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(2) = "ASTRO1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(3) = "ASTRO1 DEP - PROBE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "ASTRO1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(5) = "ASTRO1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(6) = "ASTRO1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(7) = "ASTRO1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(8) = "ASTRO1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(9) = "TOKYO1 DEP - KNIFE TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT HDG 080."
                    SIDC(10) = "TOKYO1 DEP - KNIFE TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT HDG 080."
                    SIDC(11) = "TOKYO1 DEP - KNIFE TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT HDG 080."
                    SIDC(12) = "C"
                    SIDC(13) = "N/A"
                    SIDC(14) = "TOKYO1 DEP - KNIFE TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT HDG 080."
                    SIDC(15) = "TOKYO1 DEP - KNIFE TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT HDG 080."
                    SIDC(16) = "TOKYO1 DEP - ONDER TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 190."
                    SIDC(17) = "ASTRO1 DEP - DINER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "ASTRO1 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(19) = "TOKYO1 DEP - ASTRO TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT DIRECT ASTRO."

                    SID(0) = "ASTRO1.PROBE"
                    SID(1) = "ASTRO1.PROBE"
                    SID(2) = "ASTRO1.PROBE"
                    SID(3) = "ASTRO1.PROBE"
                    SID(4) = "ASTRO1.DINER"
                    SID(5) = "ASTRO1.DINER"
                    SID(6) = "ASTRO1.DINER"
                    SID(7) = "ASTRO1.DINER"
                    SID(8) = "ASTRO1.DINER"
                    SID(9) = "TOKYO1.KNIFE - RH 080"
                    SID(10) = "TOKYO1.KNIFE - RH 080"
                    SID(11) = "TOKYO1.KNIFE - RH 080"
                    SID(12) = "C"
                    SID(13) = "N/A"
                    SID(14) = "TOKYO1.KNIFE - RH 080"
                    SID(15) = "TOKYO1.KNIFE - RH 080"
                    SID(16) = "TOKYO1.ONDER - LH 190"
                    SID(17) = "ASTRO1.DINER"
                    SID(18) = "ASTRO1.BLANK"
                    SID(19) = "TOKYO1.ASTRO - L DCT ASTRO"

                    VECTOR(0) = "TURN LEFT HDG 180"
                    VECTOR(1) = "TURN LEFT HDG 180"
                    VECTOR(2) = "TURN LEFT HDG 180"
                    VECTOR(3) = "TURN LEFT HDG 180"
                    VECTOR(4) = "TURN LEFT HDG 180"
                    VECTOR(5) = "TURN LEFT HDG 180"
                    VECTOR(6) = "TURN LEFT HDG 180"
                    VECTOR(7) = "TURN LEFT HDG 180"
                    VECTOR(8) = "TURN LEFT HDG 180"
                    VECTOR(9) = "TURN LEFT HDG 180"
                    VECTOR(10) = "TURN LEFT HDG 180"
                    VECTOR(11) = "TURN LEFT HDG 180"
                    VECTOR(12) = "C"
                    VECTOR(13) = "FLY RUNWAY HDG"
                    VECTOR(14) = "TURN RIGHT HDG 080"
                    VECTOR(15) = "TURN RIGHT HDG 080"
                    VECTOR(16) = "TURN LEFT HDG 180"
                    VECTOR(17) = "TURN LEFT HDG 180"
                    VECTOR(18) = "TURN LEFT HDG 220"
                    VECTOR(19) = "TURN LEFT HDG 220"

                    VECTORC(0) = "LH 180"
                    VECTORC(1) = "LH 180"
                    VECTORC(2) = "LH 180"
                    VECTORC(3) = "LH 180"
                    VECTORC(4) = "LH 180"
                    VECTORC(5) = "LH 180"
                    VECTORC(6) = "LH 180"
                    VECTORC(7) = "LH 180"
                    VECTORC(8) = "LH 180"
                    VECTORC(9) = "LH 180"
                    VECTORC(10) = "LH 180"
                    VECTORC(11) = "LH 180"
                    VECTORC(12) = "C"
                    VECTORC(13) = "RWY HDG"
                    VECTORC(14) = "RH 080"
                    VECTORC(15) = "RH 080"
                    VECTORC(16) = "LH 180"
                    VECTORC(17) = "LH 180"
                    VECTORC(18) = "LH 220"
                    VECTORC(19) = "LH 220"
                End If
                centreFreq = "132.300MHz."
            ElseIf airport = "IPPH" And (standardDepartureRunway = "29" Or standardDepartureRunway = "33" Or standardDepartureRunway = "11" Or standardDepartureRunway = "15") Then
                airportValidated = True
                If standardDepartureRunway = "29" Then
                    SIDC(0) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(1) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(2) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(3) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(5) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(6) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(7) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(8) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(9) = "PER2 DEP - ROSMO TRANS - AFT DEP RWY " & standardDepartureRunway & " TURNRIGHT HDG 090."
                    SIDC(10) = "PER2 DEP - ROSMO TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT HDG 090."
                    SIDC(11) = "PER2 DEP - ROSMO TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT HDG 090."
                    SIDC(12) = "PER2 DEP - HONDA TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT DIRECT HONDA."
                    SIDC(13) = "PER2 DEP - HONDA TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT DIRECT HONDA."
                    SIDC(14) = "C"
                    SID(15) = "N/A"
                    SIDC(16) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(17) = "NARXX1 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(19) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "DINER2"
                    SID(1) = "DINER2"
                    SID(2) = "DINER2"
                    SID(3) = "DINER2"
                    SID(4) = "CAMEL2"
                    SID(5) = "CAMEL2"
                    SID(6) = "CAMEL2"
                    SID(7) = "CAMEL2"
                    SID(8) = "CAMEL2"
                    SID(9) = "PER2.ROSMO - RH 090"
                    SID(10) = "PER2.ROSMO - RH 090"
                    SID(11) = "PER2.ROSMO - RH 090"
                    SID(12) = "PER2.HONDA - R DCT HONDA"
                    SID(13) = "PER2.HONDA - R DCT HONDA"
                    SID(14) = "C"
                    SID(15) = "N/A"
                    SID(16) = "DINER2"
                    SID(17) = "NARXX1"
                    SID(18) = "DINER2"
                    SID(19) = "DINER2"

                    VECTOR(0) = "TURN LEFT HDG 210"
                    VECTOR(1) = "TURN LEFT HDG 210"
                    VECTOR(2) = "TURN LEFT HDG 210"
                    VECTOR(3) = "TURN LEFT HDG 210"
                    VECTOR(4) = "TURN LEFT HDG 180"
                    VECTOR(5) = "TURN LEFT HDG 180"
                    VECTOR(6) = "TURN LEFT HDG 180"
                    VECTOR(7) = "TURN LEFT HDG 180"
                    VECTOR(8) = "TURN LEFT HDG 180"
                    VECTOR(9) = "TURN RIGHT HDG 080"
                    VECTOR(10) = "TURN RIGHT HDG 080"
                    VECTOR(11) = "TURN RIGHT HDG 080"
                    VECTOR(12) = "FLY RUNWAY HDG"
                    VECTOR(13) = "FLY RUNWAY HDG"
                    VECTOR(14) = "C"
                    VECTOR(15) = "TURN RIGHT HDG 080"
                    VECTOR(16) = "TURN LEFT HDG 210"
                    VECTOR(17) = "TURN LEFT HDG 210"
                    VECTOR(18) = "TURN LEFT HDG 270"
                    VECTOR(19) = "TURN LEFT HDG 270"

                    VECTORC(0) = "LH 210"
                    VECTORC(1) = "LH 210"
                    VECTORC(2) = "LH 210"
                    VECTORC(3) = "LH 210"
                    VECTORC(4) = "LH 180"
                    VECTORC(5) = "LH 180"
                    VECTORC(6) = "LH 180"
                    VECTORC(7) = "LH 180"
                    VECTORC(8) = "LH 180"
                    VECTORC(9) = "RH 080"
                    VECTORC(10) = "RH 080"
                    VECTORC(11) = "RH 080"
                    VECTORC(12) = "RWY HDG"
                    VECTORC(13) = "RWY HDG"
                    VECTORC(14) = "C"
                    VECTORC(15) = "RH 080"
                    VECTORC(16) = "LH 210"
                    VECTORC(17) = "LH 210"
                    VECTORC(18) = "LH 270"
                    VECTORC(19) = "LH 270"
                ElseIf standardDepartureRunway = "33" Then
                    SIDC(0) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(1) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(2) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(3) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(5) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(6) = "CAMEL2 DEP. DEP RWAY " & standardDepartureRunway & "."
                    SIDC(7) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(8) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(9) = "PER2 DEP - ROSMO TRANS VIA HAVEN CLIMB. DEP RWY " & standardDepartureRunway & "."
                    SIDC(10) = "PER2 DEP - ROSMO TRANS VIA HAVEN CLIMB. DEP RWY " & standardDepartureRunway & "."
                    SIDC(11) = "PER2 DEP - ROSMO TRANS VIA HAVEN CLIMB. DEP RWY " & standardDepartureRunway & "."
                    SIDC(12) = "PER2 DEP - HONDA TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT DIRECT HONDA."
                    SIDC(13) = "PER2 DEP - HONDA TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT DIRECT HONDA."
                    SIDC(14) = "C"
                    SIDC(15) = "N/A"
                    SIDC(16) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(17) = "NARXX1 DEP. DEP RWY " & standardDepartureRunway & "."
                    SID(18) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SIDC(19) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "DINER2"
                    SID(1) = "DINER2"
                    SID(2) = "DINER2"
                    SID(3) = "DINER2"
                    SID(4) = "CAMEL2"
                    SID(5) = "CAMEL2"
                    SID(6) = "CAMEL2"
                    SID(7) = "CAMEL2"
                    SID(8) = "CAMEL2"
                    SID(9) = "PER2.ROSMO VIA HAVEN CLIMB"
                    SID(10) = "PER2.ROSMO VIA HAVEN CLIMB"
                    SID(11) = "PER2.ROSMO VIA HAVEN CLIMB"
                    SID(12) = "PER2.HONDA - L DCT HONDA"
                    SID(13) = "PER2.HONDA - L DCT HONDA"
                    SID(14) = "C"
                    SID(15) = "N/A"
                    SID(16) = "DINER2"
                    SID(17) = "NARXX1"
                    SID(18) = "DINER2"
                    SID(19) = "DINER2"

                    VECTOR(0) = "TURN LEFT HDG 210"
                    VECTOR(1) = "TURN LEFT HDG 210"
                    VECTOR(2) = "TURN LEFT HDG 210"
                    VECTOR(3) = "TURN LEFT HDG 210"
                    VECTOR(4) = "TURN LEFT HDG 210"
                    VECTOR(5) = "TURN LEFT HDG 210"
                    VECTOR(6) = "TURN LEFT HDG 210"
                    VECTOR(7) = "TURN LEFT HDG 210"
                    VECTOR(8) = "TURN LEFT HDG 210"
                    VECTOR(9) = "TURN RIGHT HDG 090"
                    VECTOR(10) = "TURN RIGHT HDG 090"
                    VECTOR(11) = "TURN RIGHT HDG 090"
                    VECTOR(12) = "FLY RUNWAY HDG"
                    VECTOR(13) = "FLY RUNWAY HDG"
                    VECTOR(14) = "C"
                    VECTOR(15) = "TURN RIGHT HDG 090"
                    VECTOR(16) = "TURN LEFT HDG 210"
                    VECTOR(17) = "TURN LEFT HDG 210"
                    VECTOR(18) = "TURN LEFT HDG 270"
                    VECTOR(19) = "TURN LEFT HDG 210"

                    VECTORC(0) = "LH 210"
                    VECTORC(1) = "LH 210"
                    VECTORC(2) = "LH 210"
                    VECTORC(3) = "LH 210"
                    VECTORC(4) = "LH 210"
                    VECTORC(5) = "LH 210"
                    VECTORC(6) = "LH 210"
                    VECTORC(7) = "LH 210"
                    VECTORC(8) = "LH 210"
                    VECTORC(9) = "RH 090"
                    VECTORC(10) = "RH 090"
                    VECTORC(11) = "RH 090"
                    VECTORC(12) = "RWY HDG"
                    VECTORC(13) = "RWY HDG"
                    VECTORC(14) = "C"
                    VECTORC(15) = "RH 090"
                    VECTORC(16) = "LH210"
                    VECTORC(17) = "LH210"
                    VECTORC(18) = "LH270"
                    VECTORC(19) = "LH210"
                ElseIf standardDepartureRunway = "11" Then
                    SID(0) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SID(1) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SID(2) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SID(3) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SID(4) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SID(5) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SID(6) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SID(7) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SID(8) = "CAMEL2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SID(9) = "PER2 DEP - ROSMO TRANS - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SID(10) = "PER2 DEP - ROSMO TRANS - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SID(11) = "PER2 DEP - ROSMO TRANS - AFT DEP RWY " & standardDepartureRunway & " FLY RUNWAY HDG."
                    SID(12) = "PER2 DEP - HONDA TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 340."
                    SID(13) = "PER2 DEP - HONDA TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN LEFT HDG 340."
                    SID(14) = "C"
                    SID(15) = "N/A"
                    SID(16) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SID(17) = "NARXX1 DEP. DEP RWY " & standardDepartureRunway & "."
                    SID(18) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."
                    SID(19) = "DINER2 DEP. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "DINER2"
                    SID(1) = "DINER2"
                    SID(2) = "DINER2"
                    SID(3) = "DINER2"
                    SID(4) = "CAMEL2"
                    SID(5) = "CAMEL2"
                    SID(6) = "CAMEL2"
                    SID(7) = "CAMEL2"
                    SID(8) = "CAMEL2"
                    SID(9) = "PER2.ROSMO - RWY HDG"
                    SID(10) = "PER2.ROSMO - RWY HDG"
                    SID(11) = "PER2.ROSMO - RWY HDG"
                    SID(12) = "PER2.HONDA - LH 340"
                    SID(13) = "PER2.HONDA - LH 340"
                    SID(14) = "C"
                    SID(15) = "N/A"
                    SID(16) = "DINER2"
                    SID(17) = "NARXX1"
                    SID(18) = "DINER2"
                    SID(19) = "DINER2"

                    VECTOR(0) = "TURN RIGHT ARND MOUNTAIN HDG 230"
                    VECTOR(1) = "TURN RIGHT ARND MOUNTAIN HDG 230"
                    VECTOR(2) = "TURN RIGHT ARND MOUNTAIN HDG 230"
                    VECTOR(3) = "TURN RIGHT ARND MOUNTAIN HDG 230"
                    VECTOR(4) = "TURN RIGHT ARND MOUNTAIN HDG 230"
                    VECTOR(5) = "TURN RIGHT ARND MOUNTAIN HDG 180"
                    VECTOR(6) = "TURN RIGHT ARND MOUNTAIN HDG 180"
                    VECTOR(7) = "TURN RIGHT ARND MOUNTAIN HDG 180"
                    VECTOR(8) = "TURN RIGHT ARND MOUNTAIN HDG 180"
                    VECTOR(9) = "FLY RUNWAY HDG"
                    VECTOR(10) = "FLY RUNWAY HDG"
                    VECTOR(11) = "FLY RUNWAY HDG"
                    VECTOR(12) = "TURN LEFT HDG 360"
                    VECTOR(13) = "TURN LEFT HDG 360"
                    VECTOR(14) = "C"
                    VECTOR(15) = "FLY RUNWAY HDG"
                    VECTOR(16) = "TURN RIGHT ARND MOUNTAIN HDG 230"
                    VECTOR(17) = "TURN RIGHT ARND MOUNTAIN HDG 180"
                    VECTOR(18) = "TURN RIGHT ARND MOUNTAIN HDG 230"
                    VECTOR(19) = "TURN RIGHT ARND MOUNTAIN HDG 230"

                    VECTORC(0) = "RH 230"
                    VECTORC(1) = "RH 230"
                    VECTORC(2) = "RH 230"
                    VECTORC(3) = "RH 230"
                    VECTORC(4) = "RH 230"
                    VECTORC(5) = "RH 180"
                    VECTORC(6) = "RH 180"
                    VECTORC(7) = "RH 180"
                    VECTORC(8) = "RH 180"
                    VECTORC(9) = "RWY HDG"
                    VECTORC(10) = "RWY HDG"
                    VECTORC(11) = "RWY HDG"
                    VECTORC(12) = "LH 360"
                    VECTORC(13) = "LH 360"
                    VECTORC(14) = "C"
                    VECTORC(15) = "RWY HDG"
                    VECTORC(16) = "RH 230"
                    VECTORC(17) = "RH 180"
                    VECTORC(18) = "RH 230"
                    VECTORC(19) = "RH 230"
                End If
                centreFreq = "135.250MHz."
            ElseIf airport = "IGRV" And (standardDepartureRunway = "06" Or standardDepartureRunway = "24") Then
                airportValidated = True
                If standardDepartureRunway = "24" Then
                    SIDC(0) = "CELAR4 DEP - SUNST TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(1) = "CELAR4 DEP - SUNST TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(2) = "CELAR4 DEP - SUNST TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(3) = "CELAR4 DEP - SUNST TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "CELAR4 DEP - SUNST TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(5) = "CELAR4 DEP - SUNST TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(6) = "CELAR4 DEP - SUNST TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(7) = "CELAR4 DEP - SUNST TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(8) = "CELAR4 DEP - SUNST TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(9) = "THENR4 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(10) = "THENR4 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(11) = "THENR4 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(12) = "THENR4 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(13) = "THENR4 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(14) = "THENR4 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(15) = "THENR4 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(16) = "THENR4 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(17) = "THENR4 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "C"
                    SIDC(19) = "CELAR4 DEP - SPACE TRANS. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "CELAR4.SUNST"
                    SID(1) = "CELAR4.SUNST"
                    SID(2) = "CELAR4.SUNST"
                    SID(3) = "CELAR4.SUNST"
                    SID(4) = "CELAR4.SUNST"
                    SID(5) = "CELAR4.SUNST"
                    SID(6) = "CELAR4.SUNST"
                    SID(7) = "CELAR4.SUNST"
                    SID(8) = "CELAR4.SUNST"
                    SID(9) = "THENR4.BLANK"
                    SID(10) = "THENR4.BLANK"
                    SID(11) = "THENR4.BLANK"
                    SID(12) = "THENR4.BLANK"
                    SID(13) = "THENR4.BLANK"
                    SID(14) = "THENR4.BLANK"
                    SID(15) = "THENR4.BLANK"
                    SID(16) = "THENR4.BLANK"
                    SID(17) = "THENR4.BLANK"
                    SID(18) = "C"
                    SID(19) = "CELAR4.SPACE"

                    VECTOR(0) = "TURN LEFT HDG 110"
                    VECTOR(1) = "TURN LEFT HDG 110"
                    VECTOR(2) = "TURN LEFT HDG 110"
                    VECTOR(3) = "TURN LEFT HDG 110"
                    VECTOR(4) = "TURN LEFT HDG 100"
                    VECTOR(5) = "TURN LEFT HDG 100"
                    VECTOR(6) = "TURN LEFT HDG 100"
                    VECTOR(7) = "TURN LEFT HDG 100"
                    VECTOR(8) = "TURN LEFT HDG 100"
                    VECTOR(9) = "TURN LEFT HDG 110"
                    VECTOR(10) = "TURN LEFT HDG 110"
                    VECTOR(11) = "TURN LEFT HDG 110"
                    VECTOR(12) = "TURN RIGHT HDG 360"
                    VECTOR(13) = "TURN RIGHT HDG 360"
                    VECTOR(14) = "TURN LEFT HDG 100"
                    VECTOR(15) = "TURN LEFT HDG 100"
                    VECTOR(16) = "TURN LEFT HDG 100"
                    VECTOR(17) = "TURN LEFT HDG 100"
                    VECTOR(18) = "C"
                    VECTOR(19) = "TURN LEFT HDG 180"

                    VECTORC(0) = "LH 110"
                    VECTORC(1) = "LH 110"
                    VECTORC(2) = "LH 110"
                    VECTORC(3) = "LH 110"
                    VECTORC(4) = "LH 100"
                    VECTORC(5) = "LH 100"
                    VECTORC(6) = "LH 100"
                    VECTORC(7) = "LH 100"
                    VECTORC(8) = "LH 100"
                    VECTORC(9) = "LH 110"
                    VECTORC(10) = "LH 110"
                    VECTORC(11) = "LH 110"
                    VECTORC(12) = "RH 360"
                    VECTORC(13) = "RH 360"
                    VECTORC(14) = "RH 100"
                    VECTORC(15) = "RH 100"
                    VECTORC(16) = "RH 100"
                    VECTORC(17) = "RH 100"
                    VECTORC(18) = "C"
                    VECTORC(19) = "TURN LEFT HDG 180"
                ElseIf standardDepartureRunway = "06" Then
                    SIDC(0) = "YOUTH4 DEP - SUNST TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(1) = "YOUTH4 DEP - SUNST TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(2) = "YOUTH4 DEP - SUNST TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(3) = "YOUTH4 DEP - SUNST TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "YOUTH4 DEP - ENDER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(5) = "YOUTH4 DEP - ENDER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(6) = "YOUTH4 DEP - ENDER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(7) = "YOUTH4 DEP - ENDER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(8) = "YOUTH4 DEP - ENDER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(9) = "YOUTH4 DEP - ENDER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(10) = "YOUTH4 DEP - ENDER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(11) = "YOUTH4 DEP - ENDER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(12) = "YOUTH4 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(13) = "YOUTH4 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(14) = "YOUTH4 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(15) = "YOUTH4 DEP - BLANK TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(16) = "GVK1 DEP - GUESS TRANS - AFT DEP RWY " & standardDepartureRunway & " TURN RIGHT HDG 135."
                    SIDC(17) = "YOUTH4 DEP - ENDER TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "C"
                    SIDC(19) = "HAWKN1 DEP. DEP RWY " & standardDepartureRunway & "."

                    SID(0) = "YOUTH4.SUNST"
                    SID(1) = "YOUTH4.SUNST"
                    SID(2) = "YOUTH4.SUNST"
                    SID(3) = "YOUTH4.SUNST"
                    SID(4) = "YOUTH4.ENDER"
                    SID(5) = "YOUTH4.ENDER"
                    SID(6) = "YOUTH4.ENDER"
                    SID(7) = "YOUTH4.ENDER"
                    SID(8) = "YOUTH4.ENDER"
                    SID(9) = "YOUTH4.ENDER"
                    SID(10) = "YOUTH4.ENDER"
                    SID(11) = "YOUTH4.ENDER"
                    SID(12) = "YOUTH4.BLANK"
                    SID(13) = "YOUTH4.BLANK"
                    SID(14) = "YOUTH4.BLANK"
                    SID(15) = "YOUTH4.BLANK"
                    SID(16) = "GVK1.GUESS - RH 135"
                    SID(17) = "YOUTH4.ENDER"
                    SID(18) = "C"
                    SID(19) = "HAWKN1"

                    VECTOR(0) = "TURN RIGHT HDG 130"
                    VECTOR(1) = "TURN RIGHT HDG 130"
                    VECTOR(2) = "TURN RIGHT HDG 130"
                    VECTOR(3) = "TURN RIGHT HDG 130"
                    VECTOR(4) = "TURN RIGHT HDG 130"
                    VECTOR(5) = "TURN RIGHT HDG 130"
                    VECTOR(6) = "TURN RIGHT HDG 130"
                    VECTOR(7) = "TURN RIGHT HDG 130"
                    VECTOR(8) = "TURN RIGHT HDG 130"
                    VECTOR(9) = "FLY RUNWAY HDG"
                    VECTOR(10) = "FLY RUNWAY HDG"
                    VECTOR(11) = "FLY RUNWAY HDG"
                    VECTOR(12) = "FLY RUNWAY HDG"
                    VECTOR(13) = "FLY RUNWAY HDG"
                    VECTOR(14) = "FLY RUNWAY HDG"
                    VECTOR(15) = "FLY RUNWAY HDG"
                    VECTOR(16) = "TURN RIGHT HDG 090"
                    VECTOR(17) = "TURN RIGHT HDG 090"
                    VECTOR(18) = "C"
                    VECTOR(19) = "TURN RIGHT HDG 180"

                    VECTORC(0) = "RH 130"
                    VECTORC(1) = "RH 130"
                    VECTORC(2) = "RH 130"
                    VECTORC(3) = "RH 130"
                    VECTORC(4) = "RH 130"
                    VECTORC(5) = "RH 130"
                    VECTORC(6) = "RH 130"
                    VECTORC(7) = "RH 130"
                    VECTORC(8) = "RH 130"
                    VECTORC(9) = "RWY HDG"
                    VECTORC(10) = "RWY HDG"
                    VECTORC(11) = "RWY HDG"
                    VECTORC(12) = "RWY HDG"
                    VECTORC(13) = "RWY HDG"
                    VECTORC(14) = "RWY HDG"
                    VECTORC(15) = "RWY HDG"
                    VECTORC(16) = "RH 090"
                    VECTORC(17) = "RH 090"
                    VECTORC(18) = "C"
                    VECTORC(19) = "RH 180"
                End If
                centreFreq = "126.750MHz."
            ElseIf airport = "ISAU" And (standardDepartureRunway = "08" Or standardDepartureRunway = "26") Then
                airportValidated = True
                If standardDepartureRunway = "26" Then
                    SIDC(0) = "BRDR1 DEP - BEANS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(1) = "BRDR1 DEP - BEANS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(2) = "BRDR1 DEP - BEANS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(3) = "BRDR1 DEP - BEANS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "ZZ0001 DEP - ODOKU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(5) = "ZZ0001 DEP - ODOKU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(6) = "ZZ0001 DEP - ODOKU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(7) = "ZZ0001 DEP - ODOKU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(8) = "ZZ0001 DEP - ODOKU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(9) = "ZZ0001 DEP - GODLU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(10) = "ZZ0001 DEP - GODLU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(11) = "ZZ0001 DEP - GODLU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(12) = "BRDR1 DEP - SAWWPE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(13) = "BRDR1 DEP - SAWPE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(14) = "ECHHO1 DEP - SPACE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(15) = "ECHHO1 DEP - SPACE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(16) = "BRDR1 DEP - BEANS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(17) = "ZZ0001 DEP - GODLU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SID(18) = "ECHHO1 DEP - THACC TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(19) = "C"

                    SID(0) = "BRDR1.BEANS"
                    SID(1) = "BRDR1.BEANS"
                    SID(2) = "BRDR1.BEANS"
                    SID(3) = "BRDR1.BEANS"
                    SID(4) = "ZZ0001.ODOKU"
                    SID(5) = "ZZ0001.ODOKU"
                    SID(6) = "ZZ0001.ODOKU"
                    SID(7) = "ZZ0001.ODOKU"
                    SID(8) = "ZZ0001.ODOKU"
                    SID(9) = "ZZ0001.GODLU"
                    SID(10) = "ZZ0001.GODLU"
                    SID(11) = "ZZ0001.GODLU"
                    SID(12) = "BRDR1.SAWPE"
                    SID(13) = "BRDR1.SAWPE"
                    SID(14) = "ECHHO1.SPACE"
                    SID(15) = "ECHHO1.SPACE"
                    SID(16) = "BRDR1.BEANS"
                    SID(17) = "ZZ0001.GODLU"
                    SID(18) = "ECHHO1.THACC"
                    SID(19) = "C"

                    VECTOR(0) = "TURN LEFT HDG 120"
                    VECTOR(1) = "TURN LEFT HDG 120"
                    VECTOR(2) = "TURN LEFT HDG 120"
                    VECTOR(3) = "TURN LEFT HDG 120"
                    VECTOR(4) = "TURN LEFT HDG 120"
                    VECTOR(5) = "TURN LEFT HDG 120"
                    VECTOR(6) = "TURN LEFT HDG 120"
                    VECTOR(7) = "TURN LEFT HDG 120"
                    VECTOR(8) = "TURN LEFT HDG 120"
                    VECTOR(9) = "TURN RIGHT HDG 050"
                    VECTOR(10) = "TURN RIGHT HDG 050"
                    VECTOR(11) = "TURN RIGHT HDG 050"
                    VECTOR(12) = "TURN RIGHT HDG 360"
                    VECTOR(13) = "TURN RIGHT HDG 360"
                    VECTOR(14) = "TURN RIGHT HDG 020"
                    VECTOR(15) = "TURN RIGHT HDG 020"
                    VECTOR(16) = "TURN RIGHT HDG 060"
                    VECTOR(17) = "TURN RIGHT HDG 060"
                    VECTOR(18) = "TURN RIGHT HDG 360"
                    VECTOR(19) = "C"

                    VECTORC(0) = "LH 120"
                    VECTORC(1) = "LH 120"
                    VECTORC(2) = "LH 120"
                    VECTORC(3) = "LH 120"
                    VECTORC(4) = "LH 120"
                    VECTORC(5) = "LH 120"
                    VECTORC(6) = "LH 120"
                    VECTORC(7) = "LH 120"
                    VECTORC(8) = "LH 120"
                    VECTORC(9) = "RH 050"
                    VECTORC(10) = "RH 050"
                    VECTORC(11) = "RH 050"
                    VECTORC(12) = "RH 360"
                    VECTORC(13) = "RH 360"
                    VECTORC(14) = "RH 020"
                    VECTORC(15) = "RH 020"
                    VECTORC(16) = "RH 060"
                    VECTORC(17) = "RH 060"
                    VECTORC(18) = "RH 360"
                    VECTORC(19) = "C"
                ElseIf standardDepartureRunway = "08" Then
                    SIDC(0) = "BRDR1 DEP - BEANS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(1) = "BRDR1 DEP - BEANS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(2) = "BRDR1 DEP - BEANS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(3) = "BRDR1 DEP - BEANS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(4) = "SAYOW1 DEP - ODOKU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(5) = "SAYWO1 DEP - ODOKU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(6) = "SAYOW1 DEP - ODOKU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(7) = "SAYOW1 DEP - ODOKU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(8) = "SAYOW1 DEP - ODOKU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(9) = "SAYOW1 DEP - GODLU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(10) = "SAYOW1 DEP - GODLU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(11) = "SAYOW1 DEP - GODLU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(12) = "BRDR1 DEP - SAWPE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(13) = "BRDR1 DEP - SAWPE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(14) = "ECHH01 DEP - SPACE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(15) = "ECHHO1 DEP - SPACE TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(16) = "BRDR1 DEP - BEANS TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(17) = "SAYOW1 DEP - GODLU TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(18) = "ECHHO1 DEP - THACC TRANS. DEP RWY " & standardDepartureRunway & "."
                    SIDC(19) = "C"

                    SID(0) = "BRDR1.BEANS"
                    SID(1) = "BRDR1.BEANS"
                    SID(2) = "BRDR1.BEANS"
                    SID(3) = "BRDR1.BEANS"
                    SID(4) = "SAYOW1.ODOKU"
                    SID(5) = "SAYWO1.ODOKU"
                    SID(6) = "SAYOW1.ODOKU"
                    SID(7) = "SAYOW1.ODOKU"
                    SID(8) = "SAYOW1.ODOKU"
                    SID(9) = "SAYOW1.GODLU"
                    SID(10) = "SAYOW1.GODLU"
                    SID(11) = "SAYOW1.GODLU"
                    SID(12) = "BRDR1.SAWPE"
                    SID(13) = "BRDR1.SAWPE"
                    SID(14) = "ECHH01.SPACE"
                    SID(15) = "ECHHO1.SPACE"
                    SID(16) = "BRDR1.BEANS"
                    SID(17) = "SAYOW1.GODLU"
                    SID(18) = "ECHHO1.THACC"
                    SID(19) = "C"

                    VECTOR(0) = "FLY RUNWAY HDG"
                    VECTOR(1) = "FLY RUNWAY HDG"
                    VECTOR(2) = "FLY RUNWAY HDG"
                    VECTOR(3) = "FLY RUNWAY HDG"
                    VECTOR(4) = "FLY RUNWAY HDG"
                    VECTOR(5) = "FLY RUNWAY HDG"
                    VECTOR(6) = "FLY RUNWAY HDG"
                    VECTOR(7) = "FLY RUNWAY HDG"
                    VECTOR(8) = "FLY RUNWAY HDG"
                    VECTOR(9) = "FLY RUNWAY HDG"
                    VECTOR(10) = "FLY RUNWAY HDG"
                    VECTOR(11) = "FLY RUNWAY HDG"
                    VECTOR(12) = "TURN LEFT HDG 360"
                    VECTOR(13) = "TURN LEFT HDG 360"
                    VECTOR(14) = "TURN LEFT HDG 040"
                    VECTOR(15) = "TURN LEFT HDG 040"
                    VECTOR(16) = "TURN LEFT HDG 040"
                    VECTOR(17) = "FLY RUNWAY HDG"
                    VECTOR(18) = "TURN LEFT HDG 360"
                    VECTOR(19) = "C"

                    VECTORC(0) = "RWY HDG"
                    VECTORC(1) = "RWY HDG"
                    VECTORC(2) = "RWY HDG"
                    VECTORC(3) = "RWY HDG"
                    VECTORC(4) = "RWY HDG"
                    VECTORC(5) = "RWY HDG"
                    VECTORC(6) = "RWY HDG"
                    VECTORC(7) = "RWY HDG"
                    VECTORC(8) = "RWY HDG"
                    VECTORC(9) = "RWY HDG"
                    VECTORC(10) = "RWY HDG"
                    VECTORC(11) = "RWY HDG"
                    VECTORC(12) = "LH 360"
                    VECTORC(13) = "LH 360"
                    VECTORC(14) = "LH 040"
                    VECTORC(15) = "LH 040"
                    VECTORC(16) = "LH 040"
                    VECTORC(17) = "RWY HDG"
                    VECTORC(18) = "LH 360"
                    VECTORC(19) = "C"
                End If
                centreFreq = "127.825MHz."
            End If
        End If

        If airportValidated = True Then
            LST1.Items.Clear()
            LST2.Items.Clear()
            LST3.Items.Clear()
            LST4.Items.Clear()
            LST5.Items.Clear()
            LST6.Items.Clear()
            LST7.Items.Clear()
            LST1.Items.Add("READY")
            LST2.Items.Add("READY")
            LST3.Items.Add("READY")
            LST4.Items.Add("READY")
            LST5.Items.Add("READY")
            LST6.Items.Add("READY")
            LST7.Items.Add("READY")
            listBoxItems = True
        Else
            LST1.Items.Clear()
            LST2.Items.Clear()
            LST3.Items.Clear()
            LST4.Items.Clear()
            LST5.Items.Clear()
            LST6.Items.Clear()
            LST7.Items.Clear()
            LST1.Items.Add("NOT READY")
            LST2.Items.Add("NOT READY")
            LST3.Items.Add("NOT READY")
            LST4.Items.Add("NOT READY")
            LST5.Items.Add("NOT READY")
            LST6.Items.Add("NOT READY")
            LST7.Items.Add("NOT READY")
            MsgBox("Some entries are invalid, please try again. Make sure the departure runways match the airport")
        End If
        Me.ActiveControl = Nothing
    End Sub
    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LST1.Items.Add("NOT READY")
        LST2.Items.Add("NOT READY")
        LST3.Items.Add("NOT READY")
        LST4.Items.Add("NOT READY")
        LST5.Items.Add("NOT READY")
        LST6.Items.Add("NOT READY")
        LST7.Items.Add("NOT READY")

        listBoxItems = True

        sqk = True
        TB7.Text = "RND"
        climbCopy = False
        climbError = False
    End Sub
    Private Sub TB4_Leave(sender As Object, e As EventArgs) Handles TB4.Leave
        callsign = TB4.Text
        CLEARANCEGEN(0) = True
    End Sub
    Private Sub TB5_Leave(sender As Object, e As EventArgs) Handles TB5.Leave
        aircraftType = TB5.Text
        CLEARANCEGEN(1) = True
    End Sub
    Private Sub TB6_Leave(sender As Object, e As EventArgs) Handles TB6.Leave
        If TB6.Text = "IRFD" Or TB6.Text = "IGAR" Or TB6.Text = "IBLT" Or TB6.Text = "IMLR" Or TB6.Text = "ILAR" Or TB6.Text = "IPAP" Or TB6.Text = "IIAB" Or TB6.Text = "IHEN" Or TB6.Text = "IBAR" Or TB6.Text = "IZOL" Or TB6.Text = "IJAF" Or TB6.Text = "ISCM" Or TB6.Text = "ITKO" Or TB6.Text = "IDCS" Or TB6.Text = "IPPH" Or TB6.Text = "ILKL" Or TB6.Text = "IBTH" Or TB6.Text = "ISKP" Or TB6.Text = "IGRV" Or TB6.Text = "ISAU" Or TB6.Text = "CUST" Then
            destination = TB6.Text
            CLEARANCEGEN(2) = True
        Else
            CLEARANCEGEN(2) = False
        End If
    End Sub
    Private Sub CB1_CheckedChanged(sender As Object, e As EventArgs) Handles CB1.CheckedChanged
        If CB1.Checked = True Then
            CB2.Checked = False
            departureMethod = "V"
            CLEARANCEGEN(3) = True
        End If
        Me.ActiveControl = Nothing
    End Sub
    Private Sub CB2_CheckedChanged(sender As Object, e As EventArgs) Handles CB2.CheckedChanged
        If CB2.Checked = True Then
            CB1.Checked = False
            departureMethod = "S"
            CLEARANCEGEN(3) = True
        End If
        Me.ActiveControl = Nothing
    End Sub
    Private Sub TB7_Leave(sender As Object, e As EventArgs) Handles TB7.Leave
        If IsNumeric(TB7.Text) Then
            If TB7.Text Like "*8*" Or TB7.Text Like "*9*" Or TB7.Text > 7777 Or TB7.Text <= 0 Or Len(TB7.Text) <> 4 Then
                CLEARANCEGEN(4) = False
            Else
                CLEARANCEGEN(4) = True
                squawk = TB7.Text
            End If
        Else
            CLEARANCEGEN(4) = False
        End If
    End Sub
    Private Sub TB9_Leave(sender As Object, e As EventArgs) Handles TB9.Leave
        If TB9.Text = "" Then
            CUSTOMENTRIES(0) = False
            customDeparture = ""
        Else
            customDeparture = TB9.Text
            CUSTOMENTRIES(0) = True
        End If
    End Sub
    Private Sub TB10_Leave(sender As Object, e As EventArgs) Handles TB10.Leave
        If TB10.Text = "" Then
            CUSTOMENTRIES(1) = False
            customDepartureRunway = ""
        Else
            customDepartureRunway = TB10.Text
            CUSTOMENTRIES(1) = True
        End If
    End Sub
    Private Sub TB11_Leave(sender As Object, e As EventArgs) Handles TB11.Leave
        If TB11.Text = "" Then
            CUSTOMENTRIES(2) = False
            customDestination = ""
        Else
            customDestination = TB11.Text
            CUSTOMENTRIES(2) = True
        End If
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If airportValidated = True Then
            If CLEARANCEGEN(4) = False And (TB7.Text = "" Or TB7.Text = "R" Or TB7.Text = "RND") Then
                Randomize()
                squawk = (Int((Rnd()) * 7777) + 1)

                Do While squawk Like "*8*" Or squawk Like "*9*"
                    Randomize()
                    squawk = (Int((Rnd()) * 7777) + 1)
                Loop

                If Len(squawk) = 1 Then
                    squawk = "000" & squawk
                ElseIf Len(squawk) = 2 Then
                    squawk = "00" & squawk
                ElseIf Len(squawk) = 3 Then
                    squawk = "0" & squawk
                End If
                CLEARANCEGEN(4) = True
            End If

            If CLEARANCEGEN(0) = True And CLEARANCEGEN(1) = True And CLEARANCEGEN(2) = True And CLEARANCEGEN(3) = True And CLEARANCEGEN(4) = True Then
                If (CUSTOMENTRIES(2) = True And CUSTOMENTRIES(0) = False) Or (CUSTOMENTRIES(1) = True And CUSTOMENTRIES(0) = False) Or (destination = "CUST" And customDestination = "") Or (departureMethod = "S" And CUSTOMENTRIES(0) = True) Then
                    If CUSTOMENTRIES(2) = True And CUSTOMENTRIES(0) = False Then
                        custError = custError & "A custom departure must be entered when entering a custom destination. "
                    End If
                    If CUSTOMENTRIES(1) = True And CUSTOMENTRIES(0) = False Then
                        custError = custError & "A custom departure must be entered when entering a custom departure runway. "
                    End If
                    If destination = "CUST" And customDestination = "" Then
                        custError = custError & "A custom destination must be entered when entering the option. "
                    End If
                    If departureMethod = "S" And CUSTOMENTRIES(0) = True Then
                        custError = custError & "The VECTOR/CUSTOM departure method must be selected when entering a custom departure. "
                    End If

                    MsgBox(custError)
                    custError = ""
                Else
                    If departureMethod = "S" Then
                        If destination = "IRFD" Then
                            departure = SID(0)
                            PDCS = SIDC(0)
                        ElseIf destination = "IGAR" Then
                            departure = SID(1)
                            PDCS = SIDC(1)
                        ElseIf destination = "IBLT" Then
                            departure = SID(2)
                            PDCS = SIDC(2)
                        ElseIf destination = "IMLR" Then
                            departure = SID(3)
                            PDCS = SIDC(3)
                        ElseIf destination = "ILAR" Then
                            departure = SID(4)
                            PDCS = SIDC(4)
                        ElseIf destination = "IPAP" Then
                            departure = SID(5)
                            PDCS = SIDC(5)
                        ElseIf destination = "IIAB" Then
                            departure = SID(6)
                            PDCS = SIDC(6)
                        ElseIf destination = "IHEN" Then
                            departure = SID(7)
                            PDCS = SIDC(7)
                        ElseIf destination = "IBAR" Then
                            departure = SID(8)
                            PDCS = SIDC(8)
                        ElseIf destination = "IZOL" Then
                            departure = SID(9)
                            PDCS = SIDC(9)
                        ElseIf destination = "IJAF" Then
                            departure = SID(10)
                            PDCS = SIDC(10)
                        ElseIf destination = "ISCM" Then
                            departure = SID(11)
                            PDCS = SIDC(11)
                        ElseIf destination = "ITKO" Then
                            departure = SID(12)
                            PDCS = SIDC(12)
                        ElseIf destination = "IDCS" Then
                            departure = SID(13)
                            PDCS = SIDC(13)
                        ElseIf destination = "IPPH" Then
                            departure = SID(14)
                            PDCS = SIDC(14)
                        ElseIf destination = "ILKL" Then
                            departure = SID(15)
                            PDCS = SIDC(15)
                        ElseIf destination = "IBTH" Then
                            departure = SID(16)
                            PDCS = SIDC(16)
                        ElseIf destination = "ISPK" Then
                            departure = SID(17)
                            PDCS = SIDC(17)
                        ElseIf destination = "IGRV" Then
                            departure = SID(18)
                            PDCS = SIDC(18)
                        ElseIf destination = "ISAU" Then
                            departure = SID(19)
                            PDCS = SIDC(19)
                        End If
                        abrevDep = departure
                    ElseIf departureMethod = "V" Then
                        If destination = "IRFD" Then
                            departure = VECTOR(0)
                            abrevDep = VECTORC(0)
                        ElseIf destination = "IGAR" Then
                            departure = VECTOR(1)
                            abrevDep = VECTORC(1)
                        ElseIf destination = "IBLT" Then
                            departure = VECTOR(2)
                            abrevDep = VECTORC(2)
                        ElseIf destination = "IMLR" Then
                            departure = VECTOR(3)
                            abrevDep = VECTORC(3)
                        ElseIf destination = "ILAR" Then
                            departure = VECTOR(4)
                            abrevDep = VECTORC(4)
                        ElseIf destination = "IPAP" Then
                            departure = VECTOR(5)
                            abrevDep = VECTORC(5)
                        ElseIf destination = "IIAB" Then
                            departure = VECTOR(6)
                            abrevDep = VECTORC(6)
                        ElseIf destination = "IHEN" Then
                            departure = VECTOR(7)
                            abrevDep = VECTORC(7)
                        ElseIf destination = "IBAR" Then
                            departure = VECTOR(8)
                            abrevDep = VECTORC(8)
                        ElseIf destination = "IZOL" Then
                            departure = VECTOR(9)
                            abrevDep = VECTORC(9)
                        ElseIf destination = "IJAF" Then
                            departure = VECTOR(10)
                            abrevDep = VECTORC(10)
                        ElseIf destination = "ISCM" Then
                            departure = VECTOR(11)
                            abrevDep = VECTORC(11)
                        ElseIf destination = "ITKO" Then
                            departure = VECTOR(12)
                            abrevDep = VECTORC(12)
                        ElseIf destination = "IDCS" Then
                            departure = VECTOR(13)
                            abrevDep = VECTORC(13)
                        ElseIf destination = "IPPH" Then
                            departure = VECTOR(14)
                            abrevDep = VECTORC(14)
                        ElseIf destination = "ILKL" Then
                            departure = VECTOR(15)
                            abrevDep = VECTORC(15)
                        ElseIf destination = "IBTH" Then
                            departure = VECTOR(16)
                            abrevDep = VECTORC(16)
                        ElseIf destination = "ISKP" Then
                            departure = VECTOR(17)
                            abrevDep = VECTORC(17)
                        ElseIf destination = "IGRV" Then
                            departure = VECTOR(18)
                            abrevDep = VECTORC(18)
                        ElseIf destination = "ISAU" Then
                            departure = VECTOR(19)
                            abrevDep = VECTORC(19)
                        ElseIf destination = "CUST" Then
                            departure = customDeparture
                        End If
                        If CUSTOMENTRIES(0) = True Then
                            departure = customDeparture
                        End If
                    End If

                    If departure = "C" Or departure = "N/A" Then
                        If departure = "C" Then
                            MsgBox("A custom departure must be entered with a destination of the same origin.")
                        ElseIf departure = "N/A" Then
                            MsgBox("This destination is too close for a SID. Use VECTOR/CUSTOM departure method instead.")
                        End If
                    Else
                        If CUSTOMENTRIES(1) = True Then
                            departureRunway = customDepartureRunway
                        Else
                            departureRunway = standardDepartureRunway
                        End If
                        If CUSTOMENTRIES(2) = True Then
                            destination = customDestination
                        End If
                        If CUSTOMENTRIES(3) = True Then
                            initialClimb = customClimb
                            climbCopy = True
                        Else
                            initialClimb = standardInitialClimb
                            climbCopy = False
                        End If

                        If listBoxItems = True Then
                            listBoxItems = False
                            LST1.Items.Clear()
                            LST2.Items.Clear()
                            LST3.Items.Clear()
                            LST4.Items.Clear()
                            LST5.Items.Clear()
                            LST6.Items.Clear()
                            LST7.Items.Clear()
                        End If

                        If departureMethod = "V" And CUSTOMENTRIES(0) = False Then
                            PDC(CLEARCOUNT) = "```PDC FOR " & callsign & " - AUTOMATICALLY GENERATED BY DANS ATC24 CLEARANCE GENERATOR VERSION 3.0.6

" & callsign & " CLEARED " & destination & " VIA RADAR VECTORS. 
AFTER DEPARTURE RUWNAY " & departureRunway & " " & departure & "
INITAL CLIMB ALT " & initialClimb & "FT. EXPECT FURTHER CLIMB CLEARANCE WITH CENTRE ON FREQ " & centreFreq & "
SQUAWK " & squawk & ".

TO CONFIRM YOUR CLEARANCE WITH GROUND, REPORT *SQUAWK* ONLY.
WHEN READY FOR PUSH AND START REPORT AIRCRAFT TYPE AND STAND NUMBER.
```"
                        ElseIf departureMethod = "S" Then
                            PDC(CLEARCOUNT) = "```PDC FOR " & callsign & " - AUTOMATICALLY GENERATED BY DANS ACT24 CLEARANCE GENERATOR VERSION 3.0.6

" & callsign & " CLEARED " & destination & " VIA " & PDCS & "
INITIAL CLIMB ALT " & initialClimb & "FT. EXPECT FURTHER CLIMB CLEARANCE WITH CENTRE ON FREQ " & centreFreq & "
SQUAWK " & squawk & ".

TO CONFIRM YOUR CLEARANCE WITH GROUND, REPORT *SQUAWK* ONLY.
WHEN READY FOR PUSH AND START REPORT AIRCRAFT TYPE AND STAND NUMBER.
```"
                        Else
                            PDC(CLEARCOUNT) = "- PDC UNAVAIL DUE TO CUSTOM VALUES ENTERED -"
                        End If

                        My.Computer.Clipboard.SetText(PDC(CLEARCOUNT))

                        CLEARCOUNT = CLEARCOUNT + 1

                        LST1.Items.Add(callsign)
                        LST2.Items.Add(aircraftType)
                        LST3.Items.Add(destination)
                        LST4.Items.Add(departure)
                        LST5.Items.Add(departureRunway)
                        LST6.Items.Add(initialClimb)
                        LST7.Items.Add(squawk)

                        For count = 0 To 4
                            CLEARANCEGEN(count) = False
                        Next
                        TB4.Text = ""
                        TB5.Text = ""
                        TB6.Text = ""
                        TB7.Text = ""
                        TB9.Text = ""
                        TB10.Text = ""
                        TB11.Text = ""
                        TB12.Text = ""

                        CB1.Checked = False
                        CB2.Checked = False

                        For COUNT = 0 To 3
                            CUSTOMENTRIES(COUNT) = False
                        Next

                        sqk = True
                        TB7.Text = "RND"

                        If climbError = True Then
                            MsgBox("Custom climb entry invalid. Automatically reverted to standard intial climb.")
                            climbError = False
                        End If
                    End If
                End If
            End If
        End If
        Me.ActiveControl = Nothing
    End Sub
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim temp As String
        If listBoxItems = False Then
            temp = InputBox("What PDC would you like to copy again?")

            If IsNumeric(temp) And temp >= 1 And temp <= 25 Then
                PDCCall = temp
                My.Computer.Clipboard.SetText(PDC(PDCCall - 1))
            Else
                MsgBox("The value you entered was invalid.")
            End If
        End If
        Me.ActiveControl = Nothing
    End Sub
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If listBoxItems = False Then
            My.Computer.Clipboard.SetText(PDC(CLEARCOUNT - 1))
        End If
        Me.ActiveControl = Nothing
    End Sub
    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If listBoxItems = False Then
            If climbCopy = True Then
                My.Computer.Clipboard.SetText(departure)
            Else
                My.Computer.Clipboard.SetText(abrevDep)
            End If
        End If
        Me.ActiveControl = Nothing
    End Sub
    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        If listBoxItems = False Then
            My.Computer.Clipboard.SetText(squawk)
        End If
        Me.ActiveControl = Nothing
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim clear As String
        If listBoxItems = False Then
            clear = InputBox("Are you sure you want to clear ALL clearances? This will clear the departure board, as well as ALL previously stored PDCs. (Y/N)")

            If clear = "Y" Then
                For count = 0 To 24
                    PDC(count) = ""
                    squawk = ""
                    departure = ""
                    abrevDep = ""
                Next

                LST1.Items.Clear()
                LST2.Items.Clear()
                LST3.Items.Clear()
                LST4.Items.Clear()
                LST5.Items.Clear()
                LST6.Items.Clear()
                LST7.Items.Clear()
            End If
        End If
        Me.ActiveControl = Nothing
    End Sub
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        MsgBox("Version 3.0.6 includes major rework on custom entry validation, making sure you enter the required entries when your filling out a clearance. PDCs with custom entries excluding the new custom climb field will be unavailable now. As well as new colour customization!!")
        Me.ActiveControl = Nothing
    End Sub
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        MsgBox("Most of the ATC24 Clearance Generator is self explanitory, although in order to fully utilize it, you will need to know of the 2 hidden features. When entering a destination, if you wish to enter a custom destination, type 'CUST' inside the field. This then opens the custom destination field, allowing you to enter your very own destinaiton.
If you wish to randomly generate a squawk code, there are 3 valid entries you can enter in the squawk code field: RND, R, or '' (nothing). This will generate you a random, correct (squawk codes don't include numbers over 7) squawk code. Any other custom values entered for squawk codes will be validated.")
    End Sub
    Private Sub TB7_Enter(sender As Object, e As EventArgs) Handles TB7.Enter
        If sqk = True Then
            TB7.Text = ""
            sqk = False
        End If
    End Sub
    Private Sub TB12_Leave(sender As Object, e As EventArgs) Handles TB12.Leave
        If TB12.Text = "" Then
            CUSTOMENTRIES(3) = False
        Else
            If TB12.Text Like "*a*" Or TB12.Text Like "*b*" Or TB12.Text Like "*c*" Or TB12.Text Like "*d*" Or TB12.Text Like "*e*" Or TB12.Text Like "*f*" Or TB12.Text Like "*g*" Or TB12.Text Like "*h*" Or TB12.Text Like "*i*" Or TB12.Text Like "*j*" Or TB12.Text Like "*k*" Or TB12.Text Like "*l*" Or TB12.Text Like "*m*" Or TB12.Text Like "*n*" Or TB12.Text Like "*o*" Or TB12.Text Like "*p*" Or TB12.Text Like "*q*" Or TB12.Text Like "*r*" Or TB12.Text Like "*s*" Or TB12.Text Like "*t*" Or TB12.Text Like "*w*" Or TB12.Text Like "*x*" Or TB12.Text Like "*y*" Or TB12.Text Like "*z*" Or TB12.Text Like "*A" Or TB12.Text Like "*B*" Or TB12.Text Like "*C*" Or TB12.Text Like "*D*" Or TB12.Text Like "*E*" Or TB12.Text Like "*F*" Or TB12.Text Like "*G*" Or TB12.Text Like "*H*" Or TB12.Text Like "*I*" Or TB12.Text Like "*J*" Or TB12.Text Like "*K*" Or TB12.Text Like "*L*" Or TB12.Text Like "*M*" Or TB12.Text Like "*N*" Or TB12.Text Like "*O*" Or TB12.Text Like "*P*" Or TB12.Text Like "*Q*" Or TB12.Text Like "*R*" Or TB12.Text Like "*S*" Or TB12.Text Like "*T*" Or TB12.Text Like "*U*" Or TB12.Text Like "*V*" Or TB12.Text Like "*W*" Or TB12.Text Like "*X*" Or TB12.Text Like "*Y*" Or TB12.Text Like "*Z*" Then
                CUSTOMENTRIES(3) = False
                climbError = True
            Else
                If TB12.Text Like "*>*" Or TB12.Text Like "*<*" Or TB12.Text Like "*=*" Then
                    CUSTOMENTRIES(3) = True
                    customClimb = TB12.Text
                    climbError = False
                ElseIf IsNumeric(TB12.Text) Then
                    CUSTOMENTRIES(3) = True
                    customClimb = TB12.Text
                    climbError = False
                Else
                    CUSTOMENTRIES(3) = False
                    climbError = True
                End If
            End If
        End If
    End Sub
    Private Sub C1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles C1.SelectedIndexChanged
        If C1.SelectedIndex = 0 Then
            L1.BackColor = Color.Red
            L2.BackColor = Color.Red
            L3.BackColor = Color.Red
            L4.BackColor = Color.Red
        ElseIf C1.SelectedIndex = 1 Then
            L1.BackColor = Color.Green
            L2.BackColor = Color.Green
            L3.BackColor = Color.Green
            L4.BackColor = Color.Green
        ElseIf C1.SelectedIndex = 2 Then
            L1.BackColor = Color.Blue
            L2.BackColor = Color.Blue
            L3.BackColor = Color.Blue
            L4.BackColor = Color.Blue
        ElseIf C1.SelectedIndex = 3 Then
            L1.BackColor = Color.Orange
            L2.BackColor = Color.Orange
            L3.BackColor = Color.Orange
            L4.BackColor = Color.Orange
        ElseIf C1.SelectedIndex = 4 Then
            L1.BackColor = Color.Pink
            L2.BackColor = Color.Pink
            L3.BackColor = Color.Pink
            L4.BackColor = Color.Pink
        ElseIf C1.SelectedIndex = 5 Then
            L1.BackColor = Color.Yellow
            L2.BackColor = Color.Yellow
            L3.BackColor = Color.Yellow
            L4.BackColor = Color.Yellow
        ElseIf C1.SelectedIndex = 6 Then
            L1.BackColor = Color.White
            L2.BackColor = Color.White
            L3.BackColor = Color.White
            L4.BackColor = Color.White
        ElseIf C1.SelectedIndex = 7 Then
            L1.BackColor = Color.Transparent
            L2.BackColor = Color.Transparent
            L3.BackColor = Color.Transparent
            L4.BackColor = Color.Transparent
        End If
        Me.ActiveControl = Nothing
    End Sub
End Class
